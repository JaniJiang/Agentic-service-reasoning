import copy
import json
import pandas as pd
from tqdm import tqdm
from recommend.struct_display_new.parse_utils import parse_struct_block_contents
import ast

class FormatTestData:
    """
    格式化测试集，分别产出音乐和视频的标准评估集
    输出字段: CaseID, category, dataset, query, block
    """

    def __init__(self, input_path_list=None, output_path=None):
        if input_path_list is None:
            self.input_path_list = [
                "data/cloud_share/recommend/struct_display_new/analyse/analyse_metrics/input1.tsv",
                "data/cloud_share/recommend/struct_display_new/analyse/analyse_metrics/input2.tsv",
            ]
        else:
            self.input_path_list = input_path_list

        if output_path is None:
            self.output_path = "data/cloud_share/recommend/struct_display_new/analyse/analyse_metrics/output.tsv"
        else:
            self.output_path = output_path

    def process_single_file(self, input_path):
        data_list = []
        input_df = pd.read_csv(input_path, sep="\t").fillna("")
        for _, row in tqdm(input_df.iterrows(), desc=f"Processing {input_path}", total=len(input_df)):
            case_id = row["CaseID"]
            category = row["一级分类"]
            dataset = row["业务类型"]
            query = row["Query"]
            try:
                # recall_list = ast.literal_eval(row["媒体资源统计"])
                recall_list = eval(row["媒体资源统计"])
            except Exception:
                recall_list = []
            if type(recall_list) is not list or len(recall_list) == 0:
                continue
            block_list = parse_struct_block_contents(row["StructBlockContents"])
            counter = 0
            for block_item in block_list:
                try:
                    if block_item["block_type"] not in ["music", "video"]:
                        continue
                    spoken = block_item.get("spoken")
                    content = block_item.get("content")
                    if content is None:
                        continue
                    # 保证recall_list和block_list对齐，超出则break
                    if counter >= len(recall_list):
                        break
                    data_list.append({
                        "CaseID": case_id,
                        "category": category,
                        "dataset": dataset,
                        "query": query,
                        "block": json.dumps({"content": content, "spoken": spoken}, indent=4, ensure_ascii=False)
                    })
                    counter += 1
                except Exception as e:
                    print(f"error process block: {e}")
        return data_list

    def process(self):
        output_data_list = []
        for input_path in self.input_path_list:
            single_data_list = self.process_single_file(input_path)
            output_data_list.extend(single_data_list)
        output_df = pd.DataFrame(output_data_list)
        output_df.to_csv(self.output_path, sep="\t", index=False, columns=["CaseID", "category", "dataset", "query", "block"])
        print(f"文件已成功保存至： {self.output_path}")


if __name__ == "__main__":
    obj = FormatTestData()
    obj.process()
    #  python -m recommend.entity_link.analyse.step1_format_test_data