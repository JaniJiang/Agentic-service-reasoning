import requests
from typing import List
from loguru import logger


class EmbeddingClient:
    def __init__(self, vector_dim: int = 128, timeout: int = 5):
        if vector_dim not in (128, 1024):
            raise ValueError("vector_dim must be 128 or 1024")

        self.url = "http://bge-m3-ssai-http.ssai-apis-staging.chj.cloud:80/v2/models/bge-m3/infer"
        self.vector_dim = vector_dim
        self.timeout = timeout
        self.output_name = "low_vecs" if vector_dim == 128 else "dense_vecs"

    def embed(self, sentence: str) -> List[float]:
        payload = {
            "id": "1",
            "inputs": [
                {
                    "name": "query",
                    "shape": [1, 1],
                    "datatype": "BYTES",
                    "data": [sentence],
                }
            ],
            "outputs": [{"name": self.output_name}],
        }

        try:
            resp = requests.post(self.url, json=payload, timeout=self.timeout)
            resp.raise_for_status()

            for output in resp.json().get("outputs", []):
                if output.get("name") == self.output_name:
                    vec = output.get("data", [])
                    if len(vec) != self.vector_dim:
                        logger.warning("Embedding dim mismatch, expected {}, got {}", self.vector_dim, len(vec))
                    return vec

            logger.warning("Embedding output '{}' not found", self.output_name)
            return []

        except requests.RequestException as e:
            logger.warning("Embedding request failed: {}", e)
            return []


if __name__ == "__main__":
    client = EmbeddingClient(vector_dim=128)
    vec = client.embed("播放我和我的祖国")
    logger.info("vector length: {}", len(vec))

# python -m utils.nlp_utils.embedding_client_new
