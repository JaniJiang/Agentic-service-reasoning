from search.qa_bot.service_bot_miner.meta import *
from search.qa_bot.service_bot_analyse.utils.prompt import *
from tqdm import tqdm
import json
import requests
import time
from transformers import AutoTokenizer
import onnxruntime as ort
import torch
import torch.nn as nn
import numpy as np

# 模拟请求rescore模型
URL = "http://nlu-tritonserver-inference-http.ssai-apis-staging.chj.cloud/v2/models/qabot-rescore-ensemble/infer"
REQUEST = {
    "id": "wzy",
    "inputs": [
        {
            "name": "user_query",
            "shape": [
                1
            ],
            "datatype": "BYTES",
            "data": [
                [
                    "query"
                ]
            ]
        },
        {
            "name": "topk",
            "shape": [
                1
            ],
            "datatype": "UINT8",
            "data": [
                1
            ]
        },
        {
            "name": "candidate_query_list",
            "shape": [
                1,
                3
            ],
            "datatype": "BYTES",
            "data": [
                "1",
                "",
                "1"
            ]
        }
    ]
}


def semantic_deduplicate(input_list, seedlist, threshold=0.99):
    print("############## Start Smeantic Deduplicating ##############")
    output_list = []
    for index in tqdm(range(len(input_list))):
        query = input_list[index]
        if query in output_list:
            print("query: "+query+" 已在output_list中")
            continue
        REQUEST["inputs"][0]["data"] = [query]
        tmp_list = input_list[index:].copy() + seedlist
        tmp_list.remove(query)
        for question in tmp_list:
            REQUEST["inputs"][2]["data"] = ["1", question, "1"]
            response = requests.request("POST", URL, data=json.dumps(REQUEST))
            time.sleep(0.1)
            score = response.json()["outputs"][1]["data"][0]
        # prob = compute_similarity(query, tmp_list)
        # prob_list = [p[0] for p in prob[0]]
        # score = max(prob_list)
        # question = tmp_list[prob_list.index(score)]
            if float(score) >= threshold:
                print("找到类似的相似问: "+query+' '+question+", score: "+str(score))
                break
        if float(score) < threshold:
            output_list.append(query)
    return output_list


def compute_similarity(query="", question_list=[], query_list=[], tokenizer_dir="data/cloud_share/qabot_miner/bert_model/model/base_model/bert-base-chinese",
                       onnx_path="data/cloud_share/qabot_miner/bert_model/onnx_model/model.onnx"):
    if not query_list:
        pairs = ["[SEP]".join([query, question]) for question in question_list]
    elif len(query_list) == len(question_list):
        pairs = ["[SEP]".join([query_list[i], question_list[i]]) for i in range(len(question_list))]
    tokenizer = AutoTokenizer.from_pretrained(tokenizer_dir)
    train_text_encodings = tokenizer(pairs, padding=True, truncation=True,
                                     max_length=128, return_tensors="pt")
    # 加载 Onnx 打分，和上面对比
    input_ids = train_text_encodings['input_ids'].cpu().numpy()
    attention_mask = train_text_encodings['attention_mask'].cpu().numpy()
    token_type_ids = train_text_encodings['token_type_ids'].cpu().numpy()
    sess = ort.InferenceSession(onnx_path, None)  # 加载onnx模型
    onnx_output = sess.run(['output'],
                           {'input_ids': input_ids,
                            'attention_mask': attention_mask,
                            "token_type_ids": token_type_ids
                            })
    logits = torch.tensor(np.array(onnx_output))
    softmax = nn.Softmax(dim=-1)
    prob = softmax(logits)
    return prob
