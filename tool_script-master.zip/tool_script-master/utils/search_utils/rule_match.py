import re
from typing import List, Tuple
from pypinyin import pinyin, lazy_pinyin, Style


def calculate_common_ratios_set(str1: str, str2: str):
    """基于字符集合交集计算比例"""
    set1 = set(str1)
    set2 = set(str2)
    common_set = set1 & set2
    ratio1 = len(common_set) / len(set1) if len(set1) > 0 else 0
    ratio2 = len(common_set) / len(set2) if len(set2) > 0 else 0
    return ratio1, ratio2


def calculate_pinyin_match(str1: str, str2: str) -> bool:
    """计算拼音匹配度"""
    # 将文本转换为拼音
    list1 = pinyin(str1, style=Style.NORMAL, heteronym=True)
    list2 = pinyin(str2, style=Style.NORMAL, heteronym=True)
    # 两个拼音列表的长度必须相同
    if len(list1) != len(list2):
        return 0, 0, 0, [], [], [], []
    overlap_count = 0
    total_count = len(list1)
    diff_sublist1 = []
    diff_sublist2 = []
    for sublist1, sublist2 in zip(list1, list2):
        # 判断两个子列表是否有至少一个匹配的元素
        if any(item in sublist1 for item in sublist2):
            overlap_count += 1
        else:
            diff_sublist1.append(sublist1)
            diff_sublist2.append(sublist2)
    overlap_ratio = overlap_count / total_count
    return 1, overlap_ratio, overlap_count, list1, list2, diff_sublist1, diff_sublist2


def generate_pinyin(query: str, sep: str = " ") -> Tuple[List[str], str, List[str], str]:
    digit_pinyin = {
        "0": "ling", "1": "yi", "2": "er", "3": "san", "4": "si",
        "5": "wu", "6": "liu", "7": "qi", "8": "ba", "9": "jiu"
    }
    double_shengmu = ["zh", "ch", "sh"]
    single_shengmu = ["b", "c", "d", "f", "g", "h", "j", "k", "l", "m", "n", "p", "q", "r", "s", "t", "x", "z"]
    white_word_dict = {"e": "yi"}
    escape_word_list = ["live", "love"]

    def custom_errors(token: str) -> List[str]:
        """处理非汉字字符序列，拆分数字但保持纯英文字母完整"""
        result = []
        # 使用正则匹配：纯字母序列 | 数字 | 单个非字母数字字符
        parts = re.findall(r"[a-zA-Z]+|\d|[^a-zA-Z0-9]", token)
        for part in parts:
            if part.isdigit():  # 数字转换为拼音
                result.append(digit_pinyin[part])
            elif part.isalpha():  # 纯英文字母序列保持完整
                if part in white_word_dict:
                    result.append(white_word_dict[part])
                else:
                    result.append(part)
            else:  # 单个非字母数字字符（如标点符号）
                result.append(part)
        return result

    def split_pinyin(pinyin_list: List[str]) -> List[str]:
        parts = []
        for syllable in pinyin_list:
            if syllable in escape_word_list:
                parts.append(syllable)
                continue
            n = len(syllable)
            if n >= 2 and syllable[:2] in double_shengmu:  # 处理双字母声母
                parts.append(syllable[:2])
                parts.append(syllable[2:])
            elif n >= 1 and syllable[0] in single_shengmu:  # 处理单字母声母
                parts.append(syllable[0])
                parts.append(syllable[1:])
            elif n >= 1 and syllable[0] in ["y", "w"]:  # 处理以y/w开头的音节
                parts.append(syllable[0])
                parts.append(syllable[1:])
            else:  # 处理无标准声母的元音音节
                parts.append("")  # 声母为空
                parts.append(syllable)  # 整个拼音作为韵母
        return parts

    # 转换拼音
    pinyin_list = lazy_pinyin(query, style=Style.NORMAL, errors=custom_errors)
    pinyin_list = [pinyin for pinyin in pinyin_list if pinyin not in ["", " "]]  # 过滤无用字符
    pinyin_str = sep.join(pinyin_list)  # 拼接拼音
    # 拆分声母和韵母
    pinyin_split_list = split_pinyin(pinyin_list)
    pinyin_split_list = [pinyin_split for pinyin_split in pinyin_split_list if pinyin_split not in ["", " "]]  # 过滤无用字符
    pinyin_split_str = sep.join(pinyin_split_list)
    return pinyin_list, pinyin_str, pinyin_split_list, pinyin_split_str


if __name__ == "__main__":
    query = "瑞幸咖啡荣和e中心店"
    # query = "瑞幸咖啡华熙live中心a座店"
    pinyin_list, pinyin_str, pinyin_split_list, pinyin_split_str = generate_pinyin(query)
    print("query:", query)
    print("pinyin_list:", pinyin_list)
    print("pinyin_str:", pinyin_str)
    print("pinyin_split_list:", pinyin_split_list)
    print("pinyin_split_str:", pinyin_split_str)

# python -m utils.search_utils.rule_match
