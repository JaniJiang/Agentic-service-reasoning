import requests
import json
import time
import pandas as pd
url = "http://ks-engine-server-inference.ssai-apis-staging.chj.cloud:80/cloud/inner/nlp/kg/knowledge-search-engine/search"

payload = {
    "metadata": {
        "passengers": {
            "passengers": [
                {
                    "id": "platform_O6a3ahwRJtPp",
                    "ceip": True,
                    "age": 28,
                    "nickName": "大土豆",
                    "speakerVerificationId": "platform_wcVogswp6GS2",
                    "speakerSeat": "SPEAKER_SEAT_FIRST_LEFT",
                    "faceId": "platform_GJfly_MpjckE",
                    "accountId": "platform_uhsTuMeNNtL-"
                }
            ]
        },
        "dynamicInfo": {
            "position": {
                "latitude": 39.865246,
                "longitude": 116.37852,
                "country": "cn",
                "city": "北京市",
                "coordinate": "wgs84"
            }
        },
        "vehicleInfo": {
            "manufacturer": "liauto",
            "vehicleConfigCode": "255,32,6,32,48,249,255,105,253,28,95,251,1,32,226,239,175",
            "huOtaVersion": "1.0",
            "userManualVersion": "10",
            "helpAppVersion": "5000001",
            "vin": "dialog_platform_wuzhenyan",
            "vehicleModel": "VEHICLE_MODEL_X01",
            "spu": "ss2pro",
            "voiceVersion": "7.0.0.0",
            "accountId": "dialog_platform_wuzhenyan"
        },
        "requestInfo": {
            "msgId": "platform_nrtQ5zEDiYQVv_eCfTFo4",
            "sessionId": "kqcFv_ed_a3e-R5r3ODuV",
            "trackId": "R5J3bF9IA2vsjT-nLiEJH"
        },
        "appInfo": {
            "category": "com.chehejia.car.voice"
        }
    },
    "origQuery": "i8的主要竞争对手有哪些",
    "searchQuery": "理想i八续航多少",
    "searchCategory": [
        "汽车"
    ],
    "searchSlots": {
        "tag": [
            "理想i8",
            "主要竞争对手"
        ]
    },
    "searchBot": "kg-bot",
    "freshness": True,
    "timeSlots": {}
}
headers = {
    'User-Agent': 'Apifox/1.0.0 (https://www.apifox.cn)',
    'Content-Type': 'application/json'
}

api = [{"function": {"arguments": "{\"category\":\"汽车\",\"query\":\"理想i8校出来的ad max的系统尺寸\",\"tag\":\"理想i8\u0026校出来\u0026ad max\u0026系统尺寸\"}", "name": "autosearch", "thought": "涉及汽车查询查询理想i8校出来的ad max的系统尺寸"},
        "id": "call_31Zzo0ZVdJLY6p9kgEA5FEapLZ6", "type": "function"}, {"function": {"arguments": "{}", "name": "deepseek_generate", "thought": "需要走深度思考"}, "id": "call_b4424b790158be578edf", "type": "function"}]


def get_response_with_api(api):
    if len(api) == 1:
        search_query = json.loads(api[0])["function"]["arguments"]["query"]
        payload["searchQuery"] = search_query
        payload["searchSlots"]["tag"] = json.loads(api[0])["function"]["arguments"]["tag"].split("＆")
        response = requests.request("POST", url, headers=headers, data=json.dumps(payload))
        time.sleep(1)
        return response.json()
    else:
        return None


if __name__ == "__main__":
    pass
    # input_path = "autoqa_analyse/公司品牌汽车问答专项测试集-0827-v1.xlsx"
    # output_path = "autoqa_analyse/1_result.csv"
    # df = pd.read_excel(input_path)
    # response_list = []
    # for i in range(len(df)):
    #     print(i)
    #     api = json.loads(df["model_1b_output"][i])
    #     response = get_response_with_api(api)
    #     if response:
    #         response_list.append(response["data"]["bot_data"])
    #     else:
    #         response_list.append(None)
    # df["recall_response"] = response_list
    # df.to_csv(output_path, index=False)
