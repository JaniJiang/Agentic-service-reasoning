import json
import requests
from retry import retry
from loguru import logger


def print_curl_request(url, headers, json_body):
    """
    Generate and print the equivalent curl command for debugging purposes
    """
    curl_command = f"curl -X POST '{url}'"
    for header_key, header_value in headers.items():
        curl_command += f" -H '{header_key}: {header_value}'"
    if json_body:
        curl_command += f" -d '{json.dumps(json_body, ensure_ascii=False)}'"
    logger.info(f"[Generated Curl Command] {curl_command}")
    print(f"\n[Generated Curl Command] {curl_command}\n")  # print to console


class EntitySearch:

    def __init__(self, url):
        self.url = url
        self.headers = {"Content-Type": "application/json"}
        self.timeout = 10

    @retry(tries=3, delay=1)
    def search(self, request_json):
        try:
            response = requests.post(self.url, headers=self.headers, json=request_json, timeout=self.timeout)
            if response.status_code != 200:
                logger.error(
                    f"[EntitySearch] response.status_code:{response.status_code}, response.reason:{response.reason}, request_json:{request_json}")
                return None
            response_json = json.loads(response.text)
            return response_json
        except Exception as e:
            logger.error("[EntitySearch] search failed:%s", e)
        return None


if __name__ == "__main__":
    url = "http://ssai-data-center-lids-testtwo.ssai-apis-staging.chj.cloud:80/search"
    obj = EntitySearch(url)
    request_json = {
        "scene": "星巴克",
        "type": "poi",
        "city": "金华",
        "origin_query": "万达广场店",
        "search_query": "万达广场店",
        "size": 10,
        "debug": True
    }
    response_json = obj.search(request_json)
    print(json.dumps(response_json, ensure_ascii=False, indent=4))

# python -m utils.search_utils.entity_search
