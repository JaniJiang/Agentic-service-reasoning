import requests
import json
import pandas as pd
import time
from tqdm import tqdm
import subprocess


def call_curl(url, method="GET", headers=None, data=None, timeout=10):
    # 构造curl命令
    curl_command = ["curl", "-X", method]

    # 添加超时选项
    curl_command.extend(["--connect-timeout", str(timeout), "--max-time", str(timeout)])

    # 添加URL
    curl_command.append(url)

    # 添加headers
    if headers:
        for key, value in headers.items():
            curl_command.extend(["-H", f"{key}: {value}"])

    # 添加请求体
    if data:
        curl_command.extend(["-d", json.dumps(data)])

    try:
        # 调用curl命令
        result = subprocess.run(curl_command, check=True, capture_output=True, text=True)
        # 获取输出
        output = result.stdout
        return json.loads(output)  # 假设返回的是JSON格式
    except subprocess.CalledProcessError as e:
        # 处理错误
        print(f"Error calling curl: {e}")
        print(f"Return code: {e.returncode}")
        print(f"Output: {e.output}")
        print(f"Error: {e.stderr}")
        return None


def request_curl(query, url="http://10.125.136.1:12561/recall/query"):
    # 示例调用
    headers = {
        'Content-Type': 'application/json'
    }
    data = {
        "msgId": "platform_kk",
        "aiUserId": "wzy",
        "timestamp": 1730168715678,
        "voiceVersion": "6.4.0.0",
        "topK": 20,
        "extendData": {
            "vehicleConfigCode": "1,81,1,35,65,249,255,255,252,255,31,31,1,255,1,255,175",
            "vehicleModel": "X03",
            "userManualVersion": "10",
            "appVersion": {
                "help": "5000001"
            },
            "huOtaVersion": "1.0",
            "nightMode": 0,
            "spu": "ss2pro"
        },
        "input": {
            "text": query,
            "voiceImage": {
                "position": 0
            }
        }
    }
    response = call_curl(url, method="POST", headers=headers, data=data)
    time.sleep(1)
    return (response)


def request_qabot(query, url="http://10.125.136.1:12561/recall/query"):
    payload = json.dumps({
        "msgId": "platform_kk",
        "aiUserId": "wzy",
        "timestamp": 1730168715678,
        "voiceVersion": "6.4.0.0",
        "topK": 20,
        "extendData": {
            "vehicleConfigCode": "1,81,1,35,65,249,255,255,252,255,31,31,1,255,1,255,175",
            "vehicleModel": "X03",
            "userManualVersion": "10",
            "appVersion": {
                "help": "5000001"
            },
            "huOtaVersion": "1.0",
            "nightMode": 0,
            "spu": "ss2pro"
        },
        "input": {
            "text": query,
            "voiceImage": {
                "position": 0
            }
        }
    })
    headers = {
        'User-Agent': 'Apifox/1.0.0 (https://www.apifox.cn)',
        'Content-Type': 'application/json'
    }

    max_retries = 3  # 最大重试次数
    retries = 0

    while retries < max_retries:
        try:
            response = requests.request("POST", url, headers=headers, data=payload, timeout=10)
            return response.json()
        except requests.exceptions.Timeout:
            print(f"请求超时：{query}，正在重试...")
            retries += 1
            time.sleep(2)  # 间隔2秒重试
        except requests.exceptions.RequestException as e:
            print(f"请求失败：{query}, 错误：{e}")
            return {"error": str(e)}
    return None




if __name__ == "__main__":
    pass