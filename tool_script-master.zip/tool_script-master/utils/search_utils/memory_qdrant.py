import numpy as np
from typing import List, Dict


class MemoryQdrant:

    def __init__(self):
        self.vectors = {}
        self.payloads = {}
        self.querys = {}
        self.ids = []

    def _match_filter(self, payload: Dict, filter: Dict) -> bool:
        if not filter:
            return True

        for cond in filter.get("must", []):
            key = cond.get("key")
            match = cond.get("match", {})
            payload_value = payload.get(key)

            if "value" in match:
                if payload_value != match["value"]:
                    return False

            if "any" in match:
                if payload_value not in match["any"]:
                    return False

        return True

    def add_points(self, points: List[Dict]):
        for point in points:
            self.vectors[point["id"]] = np.array(point["vector"])
            self.payloads[point["id"]] = point["payload"]
            # 最新knowledge index数据从以下路径copy /mnt/pfs-guan-ssai/nlu/wuzhenyan/qabot_agent/tool_script/data/cloud/search/qa_bot/qa_data_analyse/testset/step5_knowledge_index.jsonl
            self.querys[point["id"]] = point["query"]
        self.ids = list(self.vectors.keys())

    def search(self, query_vector: List[float], top_k: int = 10, deduplicate=False, filter: Dict = None) -> List[Dict]:
        item_list = []
        query_vector = np.array(query_vector)
        # 计算余弦相似度
        similarities = {}
        # for id, vector in self.vectors.items():
        #     similarity = np.dot(query_vector, vector) / (np.linalg.norm(query_vector) * np.linalg.norm(vector))
        #     similarities[id] = similarity
        for id, vector in self.vectors.items():
            payload = self.payloads[id]

            if not self._match_filter(payload, filter):
                continue

            similarity = np.dot(query_vector, vector) / (np.linalg.norm(query_vector) * np.linalg.norm(vector))
            similarities[id] = similarity
        # 排序并获取top_k结果
        if deduplicate:
            sorted_ids = sorted(similarities, key=similarities.get, reverse=True)
            id_list = []
            for id in sorted_ids:
                payload = self.payloads[id]
                query = self.querys[id]
                try:
                    if payload["question_id"] not in id_list:    # 判断去重,不在新增query_list
                        if len(id_list) >= top_k:        # 如果id_list已满，跳过
                            continue
                        id_list.append(payload["question_id"])
                        item_list.append({
                            "id": payload["question_id"],
                            "score": similarities[id],
                            "payload": self.payloads[id],
                            "query_list": [query]
                        })
                    else:       # 在append query_list
                        for i in range(len(item_list)):
                            if item_list[i]['id'] == payload["question_id"]:
                                item_list[i]['query_list'].append(query)
                                break
                except Exception as e:
                    print(e)
                    continue
            sorted_ids = id_list
        else:
            sorted_ids = sorted(similarities, key=similarities.get, reverse=True)[:top_k]
            for id in sorted_ids:
                item = {
                    "id": id,
                    "score": similarities[id],
                    "payload": self.payloads[id],
                }
                if len(item["payload"]) == 0:
                    item["payload"]["query"] = self.querys[id]
                item_list.append(item)
        return item_list

    def search_batch(self, query_embedding_list: List[List[float]], top_k: int = 10, deduplicate: bool = False) -> List[List[Dict]]:
        """
        对一批查询向量进行批量搜索。

        参数:
            query_embedding_list (List[List[float]]): 查询向量嵌入列表。
            top_k (int): 每个查询返回的top K结果数。
            deduplicate (bool): 是否基于 "question_id" 进行去重。

        返回:
            List[List[Dict]]: 每个查询的结果列表的列表。
        """
        query_matrix = np.array(query_embedding_list)
        key_matrix = np.array(list(self.vectors.values()))

        # 归一化查询向量
        query_norms = np.linalg.norm(query_matrix, axis=1, keepdims=True)
        query_matrix_normalized = query_matrix / query_norms

        # 归一化知识向量
        key_norms = np.linalg.norm(key_matrix, axis=1, keepdims=True)
        key_nromalized = key_matrix / key_norms

        # 批量计算余弦相似度 (点积)
        similarity_matrix = np.dot(query_matrix_normalized, key_nromalized.T)

        all_results = []
        for i in range(similarity_matrix.shape[0]):  # 对每个查询进行处理
            query_i_similarities = similarity_matrix[i]  # 当前查询与所有数据库向量的相似度

            # 获取按相似度排序的数据库向量索引 (降序)
            sorted_db_indices_for_query_i = np.argsort(-query_i_similarities)

            item_list_for_query = []
            if deduplicate:
                deduplicated_items_map_for_query_i = {}
                ordered_question_ids_for_query_i = []

                for db_idx in sorted_db_indices_for_query_i:
                    original_db_id = self.ids[db_idx]
                    payload = self.payloads[original_db_id]
                    query_text_of_db_item = self.querys.get(original_db_id, "")
                    score_for_this_db_item = float(query_i_similarities[db_idx])  # 转换为 float

                    question_id = payload.get("question_id")
                    if question_id is None:
                        continue

                    if question_id not in deduplicated_items_map_for_query_i:
                        if len(ordered_question_ids_for_query_i) < top_k:
                            deduplicated_items_map_for_query_i[question_id] = {
                                "id": question_id,
                                "score": score_for_this_db_item,
                                "payload": payload,
                                "query_list": [query_text_of_db_item]
                            }
                            ordered_question_ids_for_query_i.append(question_id)
                    else:
                        deduplicated_items_map_for_query_i[question_id]['query_list'].append(query_text_of_db_item)

                item_list_for_query = [deduplicated_items_map_for_query_i[qid]
                                       for qid in ordered_question_ids_for_query_i]

            else:  # 不去重
                # 只取 top_k 个结果
                for db_idx in sorted_db_indices_for_query_i[:top_k]:
                    original_db_id = self.ids[db_idx]
                    item_list_for_query.append({
                        "id": original_db_id,
                        "score": float(query_i_similarities[db_idx]),  # 转换为 float
                        "payload": self.payloads[original_db_id]
                        # "query_list" 在非去重时通常不包含
                    })
            all_results.append(item_list_for_query)

        return all_results
