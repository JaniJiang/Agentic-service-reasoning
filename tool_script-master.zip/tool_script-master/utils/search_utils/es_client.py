import json
import requests
from typing import List
from loguru import logger
from confparser import ConfParser
from requests.auth import HTTPBasicAuth
from elasticsearch import Elasticsearch, exceptions, helpers


class ElasticSearchClient:
    """ES客户端"""

    def __init__(self, conf_key):
        self.config = ConfParser(path="conf/es.yml").to_obj()[conf_key]
        self.es = Elasticsearch(f'http://{self.config["host"]}:{self.config["port"]}',
                                http_auth=(self.config["username"], self.config["password"]))
        self.default_mapping = {
            "properties": {
                "id": {"type": "keyword"},
                "query": {"type": "keyword"},
                "domain": {"type": "keyword"},
                "topic_list": {"type": "keyword"},
            }
        }

    def check_cluster_status(self):
        """Check the status of the Elasticsearch cluster."""
        try:
            health = self.es.cluster.health()
            logger.info("Cluster Health: {}", health["status"])
        except exceptions.ConnectionError as err:
            logger.error("Error checking cluster health: {}", err)

    def create_index(self, index_name, mapping=None):
        """Create an index with the specified name."""
        index_body = {
            "settings": {
                "number_of_shards": 1,
                "number_of_replicas": 0
            },
        }
        index_body["mappings"] = mapping if mapping is not None else self.default_mapping
        try:
            response = self.es.indices.create(index=index_name, body=index_body)
            logger.info("Index created: {}", response)
            return True
        except exceptions.RequestError as err:
            logger.error("Error while creating index: {}", err)
            return False

    def delete_index(self, index_name):
        """Delete an index with the specified name."""
        try:
            response = self.es.indices.delete(index=index_name)
            logger.info("Index deleted: {}", response)
            return True
        except exceptions.RequestError as err:
            logger.error("Error while deleting index: {}", err)
            return False

    def list_all_indices(self):
        """List all available indices."""
        try:
            indices = list(self.es.indices.get_alias().keys())
            # logger.debug("Available indices: {}", indices)
            return indices
        except exceptions.ConnectionError as err:
            logger.error("Error listing indices: {}", err)
            return []

    def check_and_create_index(self, index_name, refresh_index=False, mapping=None):
        """Check if an index exists and create it if necessary."""
        indices = self.list_all_indices()
        if index_name in indices:
            if refresh_index is True:
                if self.delete_index(index_name) is True:
                    return self.create_index(index_name, mapping)
                else:
                    return True  # TODO: delete failed
            else:
                logger.info("Index already exists: {}", index_name)
                return True
        else:
            return self.create_index(index_name, mapping)

    def put_mapping(self, index_name, mapping=None):
        """Put default mapping to the specified index."""
        try:
            body = mapping if mapping is not None else self.default_mapping
            response = self.es.indices.put_mapping(index=index_name, body=body)
            logger.info("Mapping applied: {}", response)
        except exceptions.RequestError as err:
            logger.error("Error while putting mapping: {}", err)

    def load_data(self, index_name, data_list):
        """Load data into the specified index."""
        actions = [
            {
                "_op_type": "update",
                "_index": index_name,
                "_id": data["id"],
                "doc": data,
                "doc_as_upsert": True  # Use upsert functionality
            }
            for data in data_list
        ]
        success, failed_ops = helpers.bulk(self.es, actions)
        failed = len(failed_ops)
        return success, failed

    def dump_data(self, index_name, local_path, batch_size=100):
        """Dump the specified index data to local_path"""
        try:
            # 测试ES连接
            try:
                cluster_health = self.es.cluster.health()
                print(f"Cluster status: {cluster_health['status']}")
            except Exception as e:
                print(f"无法获取集群健康状态: {e}")
                return False, 0
            # 获取索引信息
            try:
                index_stats = self.es.indices.stats(index=index_name)
                doc_count = index_stats["indices"][index_name]["total"]["docs"]["count"]
                print(f"索引 '{index_name}' 包含 {doc_count} 个文档")
            except Exception as e:
                print(f"无法获取索引统计信息: {e}")
            # 使用scan获取所有数据
            query = {"query": {"match_all": {}}}
            count = 0
            with open(local_path, "w", encoding="utf-8") as f:
                # 使用helpers.scan来遍历所有文档
                for doc in helpers.scan(
                    self.es,
                    query=query,
                    index=index_name,
                    scroll="5m",  # 保持滚动5分钟
                    size=batch_size,  # 每批次获取100条
                    clear_scroll=False  # 禁用自动清理scroll
                ):
                    # 提取文档源数据
                    source_data = doc["_source"]
                    # 保留文档ID
                    source_data["_id"] = doc["_id"]
                    # 写入文件，每行一个JSON对象
                    f.write(json.dumps(source_data, ensure_ascii=False) + "\n")
                    count += 1
                    # 打印进度
                    if count % batch_size == 0:
                        print(f"Dumped {count} documents...")
            print(f"Successfully dumped {count} documents to {local_path}")
            return True, count
        except Exception as e:
            print(f"Error dumping data: {str(e)}")
            return False, 0

    def search(self, query_dsl_dict, index_name, need_parse=True):
        url = f'http://{self.config["host"]}:{self.config["port"]}/{index_name}/_search'
        headers = {"Content-Type": "application/json"}
        auth = HTTPBasicAuth(self.config["username"], self.config["password"])
        response = requests.post(url, headers=headers, data=json.dumps(query_dsl_dict), auth=auth)
        if response.status_code == 200:
            result = response.json()
            if need_parse is True:
                item_list = self.parse_result(result)
                return item_list
            return result
        logger.warning(f"[ElasticSearchClient] search faild: {response.text}")
        return []

    def parse_result(self, result):
        hits = result.get("hits", {}).get("hits", [])
        item_list = []
        for hit in hits:
            item = hit.get("_source", {})
            item["feature"] = {"recall_score": hit.get("_score", 0.0)}
            if "highlight" in hit:
                item["highlight"] = hit.get("highlight", {})
            item_list.append(item)
        return item_list


def search_item_by_id(client: ElasticSearchClient, index_name: str, item_id: str, source: List[str]):
    """通过id搜索数据"""
    query = {
        "query": {
            "term": {
                "id": {
                    "value": item_id,
                }
            }
        }
    }
    if len(source) > 0:
        query["_source"] = source
    item_list = client.search(query, index_name, need_parse=True)
    if item_list is not None and len(item_list) > 0:
        return item_list[0]
    return None


if __name__ == "__main__":
    # 查询ID
    # client = ElasticSearchClient("meta_testtwo")
    # item = search_item_by_id(client, "ssai_tv_meta", "3506597721", ["id", "publish_time", "title", "desc"])
    # print(json.dumps(item, ensure_ascii=False, indent=4))

    # 拉取数据
    # client.dump_data("ssai_tv_meta_20250706",
    #                  "data/cloud_share/search/media_search/ssai_tv_meta/ssai_tv_meta_20250706.jsonl")

    # 查询歌曲
    # client = ElasticSearchClient("kg_testtwo")
    # query = {"query": {"term": {"song_name": {"value": "暖暖"}}}}
    # item_list = client.search(query, "kg-bot-music", need_parse=True)
    # print(json.dumps(item_list, ensure_ascii=False, indent=4))
    # 查询视频
    client = ElasticSearchClient("meta_testtwo")
    # query = {"query": {"term": {"title.keyword": {"value": "战狼2"}}}}
    query = {"query": {"match": {"title": "战狼2"}}, "_source": ["title"]}
    item_list = client.search(query, "ssai_tv_meta", need_parse=True)
    print(json.dumps(item_list, ensure_ascii=False, indent=4))

# python -m utils.search_utils.es_client
