class TopicRecommendRequest:

    def __init__(self, query, answer, domain, category, api_name, msg_id, session_id, context_id, vin,
                 vehicle_model="VEHICLE_MODEL_X01",
                 vehicle_config_code="21,64,5,32,0,255,255,73,253,28,95,255,2,0,227,255,255"):
        self.request_config_json = {
            "common_metadata": {
                "request_info": {
                    "msg_id": msg_id,
                    "session_id": session_id,
                },
                "vehicle_info": {
                    "vin": vin,
                    "vehicle_model": vehicle_model,
                    "vehicle_config_code": vehicle_config_code,
                }
            },
            "session_context": [{
                "context_id": context_id,
                "input_text": query,
                "output_text": answer,
                "nlu_result": {"dialog_acts": [{"dass": [{"domain": domain, "slots": {"CATEGORY": category, "APINAME": api_name}}]}]},
            }]
        }

    def set_answer(self, answer):
        self.request_config_json["session_contexts"]["output_text"] = answer

    def set_domain(self, domain):
        self.request_config_json["session_contexts"]["nlu_result"]["dialog_acts"][0]["dass"][0]["domain"] = domain

    def set_category(self, category):
        self.request_config_json["session_contexts"]["nlu_result"]["dialog_acts"][0]["dass"][0]["slots"]["CATEGORY"] = category

    def set_api_name(self, api_name):
        self.request_config_json["session_contexts"]["nlu_result"]["dialog_acts"][0]["dass"][0]["slots"]["APINAME"] = api_name

    def set_msg_id(self, msg_id):
        self.request_config_json["common_metadata"]["request_info"]["msg_id"] = msg_id

    def set_session_id(self, session_id):
        self.request_config_json["session_contexts"]["context_id"] = session_id

    def set_context_id(self, context_id):
        self.request_config_json["session_contexts"]["context_id"] = context_id

    def set_vin(self, vin):
        self.request_config_json["common_metadata"]["vehicle_info"]["vin"] = vin

    def set_vehicle_model(self, vehicle_model):
        self.request_config_json["common_metadata"]["vehicle_info"]["vehicle_model"] = vehicle_model

    def set_vehicle_config_code(self, vehicle_config_code):
        self.request_config_json["common_metadata"]["vehicle_info"]["vehicle_config_code"] = vehicle_config_code

    def get_request_recommend_config(self):
        return self.request_config_json


class TopicRecommendResponse():

    def __init__(self, topic_list=[], msg_id=""):
        self.topic_list = topic_list
        self.msg_id = msg_id

    def set_topic_list(self, topic_list):
        self.topic_list = topic_list

    def set_msg_id(self, msg_id):
        self.msg_id = msg_id

    def _repr__(self):
        return (f"Response(topic_list={self.topic_list!r}, msg_id={self.msg_id!r})")

    def __str__(self):
        return (f"Response:\n"
                f"topic_list: {self.topic_list}\n"
                f"msg_id: {self.msg_id}")

    def to_dict(self):
        return {"topic_list": self.topic_list, "msg_id": self.msg_id}
