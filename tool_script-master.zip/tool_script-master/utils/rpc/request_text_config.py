import json
import uuid
import re
from utils.rpc.consts import *


class TextRequest:
    def __init__(self, query, session_context_list):
        self.request_text_json = {
            "text_req_data": {
                "input": {
                    "text": query,
                    "display_text": query,
                    "imageUploadStrategy": 2,
                    "current_session": {},
                    "session_context_v2_list": session_context_list,
                    "conversation_status": "CS_DISCONTINUOUS",
                    "wakeupStatus": "WS_WAKEUP",
                    "wakeupPosition": "SPEAKER_SEAT_FIRST_LEFT",
                    "soundSourceLocation": "1",
                    "voiceImage": "VOICE_IMAGE_FIRST_ROW",
                    "speechRejectScore": {},
                    "occupantFaceOrientation": {},
                    "staticsCarData": {
                        "APPLICATION_STATE": "{\"appInfo\":{\"taskmaster\":{\"appList\":{\"copilot\":[{\"appName\":\"蓝牙音乐\",\"packageName\":\"com.lixiang.car.bluetoothmusic\"},{\"appName\":\"绘画大师\",\"packageName\":\"com.lixiang.car.paintingmaster\"},{\"appName\":\"哔哩哔哩\",\"packageName\":\"com.bilibili.bilithings\"},{\"appName\":\"美团\",\"packageName\":\"com.lixiang.car.meituan\"},{\"appName\":\"腾讯视频\",\"packageName\":\"com.lixiang.car.x.tencentvideo\"},{\"appName\":\"网易云音乐\",\"packageName\":\"com.lixiang.neteasemusic\"},{\"appName\":\"浏览器\",\"packageName\":\"com.lixiang.car.browser\"},{\"appName\":\"舱内后视\",\"packageName\":\"com.lixiang.irvcamera\"},{\"appName\":\"有线投屏\",\"packageName\":\"com.lixiang.sharescreen\"},{\"appName\":\"无线投屏\",\"packageName\":\"com.lixiang.wirelesscast\"},{\"appName\":\"得到\",\"packageName\":\"com.lixiang.car.dedao\"},{\"appName\":\"QQ音乐\",\"packageName\":\"com.lixiang.car.qqmusic\"},{\"appName\":\"爱奇艺\",\"packageName\":\"com.lixiang.car.x.video\"},{\"appName\":\"喜马拉雅\",\"packageName\":\"com.ximalaya.ting.android.car.x01\"},{\"appName\":\"小红书\",\"packageName\":\"com.lixiang.car.xhs\"}],\"driver\":[{\"appName\":\"地图\",\"packageName\":\"com.liauto.onemap\"},{\"appName\":\"环境感知\",\"packageName\":\"com.liauto.onemap\"},{\"appName\":\"蓝牙音乐\",\"packageName\":\"com.lixiang.car.bluetoothmusic\"},{\"appName\":\"行车记录仪\",\"packageName\":\"com.lixiang.car.dvr\"},{\"appName\":\"绘画大师\",\"packageName\":\"com.lixiang.car.paintingmaster\"},{\"appName\":\"天气\",\"packageName\":\"com.lixiang.car.weather\"},{\"appName\":\"哔哩哔哩\",\"packageName\":\"com.bilibili.bilithings\"},{\"appName\":\"美团\",\"packageName\":\"com.lixiang.car.meituan\"},{\"appName\":\"腾讯视频\",\"packageName\":\"com.lixiang.car.x.tencentvideo\"},{\"appName\":\"网易云音乐\",\"packageName\":\"com.lixiang.neteasemusic\"},{\"appName\":\"蓝牙电话\",\"packageName\":\"com.chehejia.car.btphone\"},{\"appName\":\"设置\",\"packageName\":\"com.chehejia.car.carsettings\"},{\"appName\":\"充电管理\",\"packageName\":\"com.chehejia.car.chargemanagement\"},{\"appName\":\"浏览器\",\"packageName\":\"com.lixiang.car.browser\"},{\"appName\":\"车辆中心\",\"packageName\":\"com.lixiang.car.carcenter\"},{\"appName\":\"供电管理\",\"packageName\":\"com.lixiang.car.discharger\"},{\"appName\":\"帮助中心\",\"packageName\":\"com.lixiang.car.helpcenter\"},{\"appName\":\"本地音乐\",\"packageName\":\"com.lixiang.car.localmusic\"},{\"appName\":\"任务大师\",\"packageName\":\"com.lixiang.car.taskmaster\"},{\"appName\":\"调音大师\",\"packageName\":\"com.lixiang.car.tuning\"},{\"appName\":\"全景影像\",\"packageName\":\"com.lixiang.car.x.svm\"},{\"appName\":\"电子后视镜\",\"packageName\":\"com.lixiang.car.x.svm\"},{\"appName\":\"FM\",\"packageName\":\"com.lixiang.fmradio\"},{\"appName\":\"舱内后视\",\"packageName\":\"com.lixiang.irvcamera\"},{\"appName\":\"有线投屏\",\"packageName\":\"com.lixiang.sharescreen\"},{\"appName\":\"理想遥控器\",\"packageName\":\"com.lixiang.sslink\"},{\"appName\":\"无线投屏\",\"packageName\":\"com.lixiang.wirelesscast\"},{\"appName\":\"得到\",\"packageName\":\"com.lixiang.car.dedao\"},{\"appName\":\"QQ音乐\",\"packageName\":\"com.lixiang.car.qqmusic\"},{\"appName\":\"爱奇艺\",\"packageName\":\"com.lixiang.car.x.video\"},{\"appName\":\"喜马拉雅\",\"packageName\":\"com.ximalaya.ting.android.car.x01\"},{\"appName\":\"应用中心\",\"packageName\":\"com.lixiang.appstore\"},{\"appName\":\"小红书\",\"packageName\":\"com.lixiang.car.xhs\"}],\"rear\":[{\"appName\":\"蓝牙音乐\",\"packageName\":\"com.lixiang.car.bluetoothmusic\"},{\"appName\":\"绘画大师\",\"packageName\":\"com.lixiang.car.paintingmaster\"},{\"appName\":\"哔哩哔哩\",\"packageName\":\"com.bilibili.bilithings\"},{\"appName\":\"腾讯视频\",\"packageName\":\"com.lixiang.car.x.tencentvideo\"},{\"appName\":\"网易云音乐\",\"packageName\":\"com.lixiang.neteasemusic\"},{\"appName\":\"浏览器\",\"packageName\":\"com.lixiang.car.browser\"},{\"appName\":\"帮助中心\",\"packageName\":\"com.lixiang.car.helpcenter\"},{\"appName\":\"有线投屏\",\"packageName\":\"com.lixiang.sharescreen\"},{\"appName\":\"无线投屏\",\"packageName\":\"com.lixiang.wirelesscast\"},{\"appName\":\"得到\",\"packageName\":\"com.lixiang.car.dedao\"},{\"appName\":\"QQ音乐\",\"packageName\":\"com.lixiang.car.qqmusic\"},{\"appName\":\"爱奇艺\",\"packageName\":\"com.lixiang.car.x.video\"},{\"appName\":\"喜马拉雅\",\"packageName\":\"com.ximalaya.ting.android.car.x01\"},{\"appName\":\"小红书\",\"packageName\":\"com.lixiang.car.xhs\"}]},\"appVersion\":\"6.2.1\",\"screenInfo\":{\"confirmDialog\":0,\"pageId\":-1}}}}",
                        "SCREEN_INFO": "{\"screens\":[{\"foregroundApp\":\"com.lixiang.psglauncher\",\"originatorList\":[],\"position\":\"rear\",\"scenes\":[]},{\"dcsData\":[],\"foregroundApp\":\"com.lixiang.car.paintingmaster\",\"originatorList\":[],\"position\":\"driver\",\"scenes\":[]},{\"foregroundApp\":\"com.lixiang.newlauncher\",\"originatorList\":[],\"position\":\"passenger\",\"scenes\":[]}]}",
                        "gesture": "{\"ai_driver\":false,\"area\":0,\"location\":0,\"score\":0.0,\"type\":7,\"version\":2}",
                        "resume_chat_supported": "true",
                        # "CAR_SIGNAL": "{\"Li_PlateNumber\": {\"v\":\"京A66666\"}}",
                        "ts": "0"
                    }
                }
            }
        }

        self.safe_status_dict = {
            "SDS_UNKNOWN": 0,
            "SDS_SAFE": 1,
            "SDS_FALLBACK": 2,
            "SDS_INTERVENE": 3,
            "SDS_UNSAFE": 4,
            "SDS_UNDETECT": 5
        }

        self.answer_source_dict = {
            "ST_FREE_DIALOGUE": 1,
            "ST_LLM_DIALOGUE": 2
        }

    def set_query(self, query):
        self.request_text_json["text_req_data"]["input"]["text"] = query
        self.request_text_json["text_req_data"]["input"]["display_text"] = query

    def set_source_location(self, source_location):
        self.request_text_json["text_req_data"]["input"]["soundSourceLocation"] = source_location

    def set_wakeup_location(self, wakeup_location):
        self.request_text_json["text_req_data"]["input"]["wakeupPosition"] = wakeup_location

    def set_child(self):
        self.request_text_json["text_req_data"]["input"]["wakeupPosition"] = "SPEAKER_SEAT_FIRST_LEFT"

    def set_session(self, input, output, input_checked="SDS_SAFE", output_checked="SDS_SAFE", answer_source=""):
        if answer_source == "":
            answer_source = 0
        else:
            answer_source = self.answer_source_dict[answer_source]
        query_status = self.safe_status_dict[input_checked] if input_checked in self.safe_status_dict.keys() else 0
        answer_status = self.safe_status_dict[output_checked] if output_checked in self.safe_status_dict.keys() else 0
        session_context = {
            "inputText": input,
            "outputText": output,
            "sessionType": answer_source,
            "safeDetectInfo": {"queryStatus": query_status, "responseStatus": answer_status}
        }
        self.request_text_json["text_req_data"]["input"]["session_context_v2_list"].append(session_context)

    def set_session_context(self, session_context):
        self.request_text_json["text_req_data"]["input"]["session_context_v2_list"].append(session_context)

    def cp_session_context(self, session_context):
        self.request_text_json["text_req_data"]["input"]["session_context_v2_list"] = session_context

    def clear_session(self):
        self.request_text_json["text_req_data"]["input"]["session_context_v2_list"] = []

    def set_conversation_status(self, conversation_status):
        self.request_text_json["text_req_data"]["input"]["conversation_status"] = conversation_status

    def set_statics_car_data(self, car_data):
        self.request_text_json["text_req_data"]["input"]["staticsCarData"] = car_data

    def get_text_request(self):
        return self.request_text_json


# 上文回复固定
def session_context_multi_rounds(input_session):
    multi_rounds = []
    if input_session in NONE_LIST:
        return multi_rounds
    if input_session not in NONE_LIST:
        try:
            input_session = re.sub(r'[\x00-\x1F\x7F]', '', input_session)
            session = json.loads(input_session)
        except json.JSONDecodeError as e:
            print(f"JSON 解码错误: {e}")
            return "error"
        for entry in session:
            user = entry.get('user', "")
            assistant = entry.get('assistant', "")
            context_id = context_generate()
            session_context_list = {
                "context_id": context_id,  # 上文id, 随便写
                "input_text": user,  # 上文
                "speaker_seat": 1,
                "nlu_result": [],  # das
                "nlu_source": 2,
                "act_results": [{
                    "execute_code": "successful",
                    "domain": "system",
                    "source_location": 1
                }],
                "output_text": assistant,
                "session_type": 1,
                "safe_detect_info": {
                    "query_status": 1,
                    "response_status": 1
                }
            }
            multi_rounds.append(session_context_list)
    return multi_rounds


def session_context_multi_rounds_painting(session, dialog_acts):
    multi_rounds = []
    if session in NONE_LIST:
        return multi_rounds
    if session not in NONE_LIST:
        context_id = context_generate()
        session_context_list = {
            "context_id": context_id,  # 上文id, 随便写
            "input_text": session,  # 上文
            "speaker_seat": 1,
            # "nlu_result": { # das
            #     "dialog_acts": [{
            #     "dass": [
            #         {
            #             "domain": "gpt_paintingmaster",
            #             "action": "paint",
            #             "slots": {
            #                 "category": "动物",
            #                 "keyphrase": "一个蓝色的小狗",
            #                 "style": ""
            #             }
            #         }]
            #      }]
            # }, # das
            "nlu_result": {"dialog_acts": dialog_acts},
            "nlu_source": 2,
            "act_results": [{
                "execute_code": "successful",
                "domain": "gpt_paintingmaster",  # system
                "source_location": 1
            }],
            "output_text": "收到，正在准备绘图，稍等一下哦。",
            "session_type": 1,
            "safe_detect_info": {
                "query_status": 1,
                "response_status": 1
            }
        }
        multi_rounds.append(session_context_list)
    return multi_rounds


def context_generate():
    text = "context_id_test_"
    random_str = uuid.uuid4().hex[:6]
    output = text + random_str
    return output


def session_generate():
    text = "session_id_test_"
    random_str = uuid.uuid4().hex[:6]
    output = text + random_str
    return output

def record_generate():
    text = "record_id_test_"
    random_str = uuid.uuid4().hex[:6]
    output = text + random_str
    return output

def generate():
    text = "crania_test_"
    random_str = uuid.uuid4().hex[:8]
    output = text + random_str
    return output


# 上文回复不固定
def handle_session_without_answer():
    pass


if __name__ == "__main__":
    query = "行程预算如何合理分配"
    input_session = '''
    [{"user": "帮我做一个青甘大环线的十天的行程", "assistant": "青甘大环线十日游的行程如下：\n\n1. 第一天：从西宁出发，前往湟源，全程约122公里，耗时约2小时。途中可以游览日月山（约1-3小时），这是青海省内外流域的天然分界线，东侧是塞上江南风光，西侧是草原辽阔、牛羊成群。然后可以参观赞普林卡景区（约1-3小时），这是世界上唯一的一个藏王寺院。最后可以游览丹噶尔古城（约3小时以上），这是唐蕃古道和茶马古道的要冲。\n\n2. 第二天：从湟源前往黑马河镇，全程249公里左右，耗时约3小时29分钟左右。途中可以欣赏环湖西路（约1-3小时）的美景，这是青海湖西侧离湖最近的公路，风光绝美。最后可以前往黑马河住宿。\n\n3. 第三天：从黑马河前往德令哈，全程275公里左右，耗时3小时50分钟左右。途中可以欣赏刚察草原（约1-3小时）的美景。\n\n4. 第四天：从德令哈前往格尔木市，全程336公里，耗时约4小时。途中可以参观海子诗歌陈列馆（约1-2小时），这是展出海子的代表诗作和相关的资料的地方。然后可以前往可鲁克湖-托素湖自然保护区，看青藏铁路从两湖间穿过、打卡外星人遗址。之后可以游览察尔汗盐湖（约1小时左右）。\n\n5. 第五天：从格尔木市出发，前往大柴旦，全程约193.6公里，耗时约5小时。途中可以欣赏柴达木盆地的美景。\n\n6. 第六天：从大柴旦前往茫崖，全程约280公里，耗时约4小时。途中可以欣赏戈壁、沙棘、草甸与远处的雪山映衬下的尕海湖（约1-3小时）。\n\n7. 第七天：从茫崖前往敦煌，全程约576公里，耗时约7小时。途中可以欣赏莫高窟（约1-3小时）的美景。\n\n8. 第八天：从敦煌前往瓜州，全程约100公里，耗时约1小时。途中可以欣赏鸣沙山月牙泉（约1-3小时）的美景。\n\n9. 第九天：从瓜州前往嘉峪关市，全程约100公里，耗时约1小时。途中可以欣赏嘉峪关关城（约1-3小时）的美景。\n\n10. 第十天：从嘉峪关市前往张掖，全程约100公里，耗时约1小时。途中可以欣赏张掖丹霞地质公园（约1-3小时）的美景。然后可以前往祁连，全程约180公里，耗时约2小时。途中可以欣赏祁连山的美景。最后可以前往门源，全程约100公里，耗时约1小时。途中可以欣赏门源油菜花（约1-3小时）的美景。然后可以返回西宁，全程约150公里，耗时约2小时。\n\n这就是青甘大环线十日游的行程，希望你旅途愉快！"}]
    '''
    session_context_list = session_context_multi_rounds(input_session)
    request = TextRequest(query, session_context_list)
    print(request.get_text_request())
