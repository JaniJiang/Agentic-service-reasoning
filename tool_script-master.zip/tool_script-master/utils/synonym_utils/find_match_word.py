"""
完全匹配逻辑，判断query是否命中
"""
import pandas as pd


class WordsItem:
    def __init__(self, word, index_arr, replace=None, drop=False):
        self.word = word
        self.index_arr = index_arr
        self.replace = replace
        self.drop = drop

    def __repr__(self):
        return f"WordsItem(word={self.word}, index_arr={self.index_arr}, replace={self.replace})"


def find_intersection(nums1, nums2):
    nums_map = set(nums1[0].index_arr)
    intersection = [num for num in nums2[0].index_arr if num in nums_map]
    return list(set(intersection))  # 转换为集合去重，然后转换回列表


def find_subset(nums1, nums2, i, j):
    set1 = set(nums1[0].index_arr)
    set2 = set(nums2[0].index_arr)

    is_subset1 = set1.issubset(set2)
    is_subset2 = set2.issubset(set1)

    if is_subset1 and is_subset2:
        return i, True  # nums1 和 nums2 互为子集，返回 nums1 作为子集
    elif is_subset1:
        return i, True  # nums1 是 nums2 的子集，返回 nums1 作为子集
    elif is_subset2:
        return j, True  # nums2 是 nums1 的子集，返回 nums2 作为子集
    else:
        return [], False  # 不是子集关系，返回空列表


def find_substring_index_arr(main_string, sub_string, standard_string):
    indices = []

    # 获取主串和子串的长度
    main_len = len(main_string)
    sub_len = len(sub_string)

    # 遍历主串
    for i in range(main_len - sub_len + 1):
        # 判断主串当前位置开始是否匹配子串
        match = True
        for j in range(sub_len):
            if main_string[i + j] != sub_string[j]:
                match = False
                break

        # 如果匹配，则将当前位置添加到结果中
        if match:
            indices.append(i)

    res = []
    for index in indices:
        x = [index + j for j in range(sub_len)]
        if len(x) > 0:
            res.append(WordsItem(sub_string, x, standard_string))

    return res


def find_hit_words(query, key_words, filter_drop):
    words_index_arrs = []
    for k, v in key_words.items():
        for w in v:
            x = find_substring_index_arr(query.lower(), w.lower(), k)
            if x:
                words_index_arrs.append(WordsItem(w, x, k))

    if not words_index_arrs:
        return []

    # 第一遍筛选，有交集，但不互为子集,则剔除
    for i in range(len(words_index_arrs) - 1):
        for j in range(i + 1, len(words_index_arrs)):
            inter = find_intersection(words_index_arrs[i].index_arr, words_index_arrs[j].index_arr)
            if inter:
                _, is_sub = find_subset(words_index_arrs[i].index_arr, words_index_arrs[j].index_arr, i, j)
                if not is_sub:
                    words_index_arrs[i].drop = True
                    words_index_arrs[j].drop = True

    # 第二遍筛选，有交集，相互之间有子集,则剔除子集
    for i in range(len(words_index_arrs) - 1):
        if words_index_arrs[i].drop:
            continue
        for j in range(i + 1, len(words_index_arrs)):
            if words_index_arrs[j].drop:
                continue
            inter = find_intersection(words_index_arrs[i].index_arr, words_index_arrs[j].index_arr)
            if inter:
                index, is_sub = find_subset(words_index_arrs[i].index_arr, words_index_arrs[j].index_arr, i, j)
                if is_sub:
                    words_index_arrs[index].drop = True

    # 排序
    # words_index_arrs.sort(key=lambda x: x.index_arr)

    if filter_drop:
        res = [item for item in words_index_arrs if not item.drop]
    else:
        res = words_index_arrs

    return res

# 读取实体列表


def read_txt_to_dataframe(file_path):
    try:
        df = pd.read_csv(file_path, sep='\t', header=None, names=['standard', 'general'], engine='python')
        df['general'] = df['general'].apply(lambda x: x.split('、'))
        return df
    except FileNotFoundError:
        print(f"文件 {file_path} 未找到。")
    except Exception as e:
        print(f"读取文件时发生错误：{e}")


if __name__ == "__main__":
    # 示例使用
    # 查找
    print("查找示例")
    main_string = "别克GL8的价格是多少"
    outer_path = "search/qa_bot/service_bot_analyse/vocab/synonym.tsv"

    # 读取实体词字典
    outer_df = read_txt_to_dataframe(outer_path)
    outer_dict = outer_df.set_index(outer_df.columns[0])[outer_df.columns[1]].to_dict()

    result = find_hit_words(main_string, outer_dict, True)
    for item in result:
        print(item)
    print(f"命中词：{result};\n同义词:{outer_dict[result[0].word]}")
