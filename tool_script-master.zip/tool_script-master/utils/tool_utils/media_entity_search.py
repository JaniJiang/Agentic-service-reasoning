import json
from utils.search_utils.es_client import ElasticSearchClient


class MediaEntitySearch:

    def __init__(self, entity_type):
        self.entity_type = entity_type
        if self.entity_type == "video":
            cluster_name = "meta_testtwo"
        elif self.entity_type == "music":
            cluster_name = "kg_testtwo"
        else:
            raise ValueError(f"entity_type[{self.entity_type}] unsupported")
        self.es_client = ElasticSearchClient(cluster_name)

    def search(self, entity_name):
        if self.entity_type == "video":
            return self.search_video(entity_name)
        elif self.entity_type == "music":
            return self.search_music(entity_name)

    def search_video(self, entity_name):
        query_dsl_dict = {
            "query": {
                "bool": {
                    "should": [
                        {"term": {"title.keyword": entity_name}},
                        {"term": {"alias.keyword": entity_name}},  # 线上使用alias
                    ],
                    "minimum_should_match": 1
                }
            },
            "sort": {"hot": {"order": "desc"}},
            # "_source": ["id", "title", "alias", "area", "actors", "director", "desc"],
            "_source": ["id", "title", "alias", "area", "actors", "director"],
            "size": 20
        }
        item_list = self.es_client.search(query_dsl_dict, "ssai_tv_meta", need_parse=True)
        return item_list

    def search_music(self, entity_name):
        query_dsl_dict = {
            "query": {
                "bool": {
                    "should": [
                        {"term": {"song_name": entity_name}},  # 线上使用song_name
                        {"term": {"alias.keyword": entity_name}},
                    ],
                    "minimum_should_match": 1
                }
            },
            "sort": {"comment_num": {"order": "desc"}},
            "_source": ["id", "song_name", "alias", "singer", "album_name",
                        "language_type", "published_time", "comment_num"],
            "size": 100
        }
        item_list = self.es_client.search(query_dsl_dict, "kg-bot-music", need_parse=True)
        return item_list


if __name__ == "__main__":
    entity_type = "music"  # video | music
    entity_name = "终わらないﾘズﾑ"  # 战狼2 ｜ 暖暖
    search_obj = MediaEntitySearch(entity_type)
    search_result = search_obj.search(entity_name)
    print(json.dumps(search_result, ensure_ascii=False, indent=4))

# python -m utils.tool_utils.media_entity_search
