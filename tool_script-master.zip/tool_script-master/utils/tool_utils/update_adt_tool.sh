#!/bin/bash
# bash utils/tool_utils/update_adt_tool.sh

tool_path="data/cloud_share/tool/adt"
ls -l ${tool_path}
rm ${tool_path}
sudo wget -O ${tool_path} http://172.21.194.41:8888/tools/ark/tools/adt
sudo chmod 777 ${tool_path}
ls -l ${tool_path}
