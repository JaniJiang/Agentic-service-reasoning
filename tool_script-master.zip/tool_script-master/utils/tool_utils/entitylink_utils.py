import requests
from loguru import logger
from retry import retry

class EntityLinkApi:

    def __init__(self, url, timeout=10):
        self.url = url
        self.headers = {"Content-Type": "application/json"}
        self.timeout = timeout

    @retry(tries=3, delay=1)
    def post(self, body: dict):

        try:
            resp = requests.post(self.url, headers=self.headers, json=body, timeout=self.timeout)
            if resp.status_code != 200:
                logger.error(f"[EntityLinkApi] Error status_code={resp.status_code}, reason={resp.reason}, req_body={body}")
                return None
            return resp.json()
        except Exception as e:
            logger.error(f"[EntityLinkApi] Post failed: {e}, req_body={body}")
            return None
        
    @staticmethod
    def call_entity_link(query, link_type):
        return {
            "metadata": {
                "dynamicInfo": {},
                "vehicleInfo": {
                    "vehicleConfigCode": "1,34,1,0,50,59,255,0,253,255,31,255,0,31,227,255,255",
                    "huOtaVersion": "11.4.0",
                    "userManualVersion": "1745251200",
                    "helpAppVersion": "7005000",
                    "vin": "WEB4ba9bba1111111",
                    "vehicleModel": "VEHICLE_MODEL_X03",
                    "spu": "ss3pro",
                    "voiceVersion": "7.5.0.0",
                    "huVersion": "11.4.0"
                },
                "requestInfo": {
                    "msgId": "0zg9kYdv9OtVyV6bY65GNyf1eKr5zult",
                    "recordId": "WEB4ba9bba1111111_click_wakeup_location_1_2025-07-17-11_11_46_118"
                }
            },
            "query": query,
            "linkType": link_type
        }

if __name__ == "__main__":
    url = "http://ks-engine-server-inference.ssai-apis-staging.chj.cloud:80/cloud/inner/nlp/kg/knowledge-search-engine/entity-link"
    obj = EntityLinkApi(url)