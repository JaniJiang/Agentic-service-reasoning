import json
import requests
from retry import retry
from loguru import logger
from confparser import ConfParser


class ApiHub:

    def __init__(self, url, call_name):
        self.config = ConfParser(path="conf/apihub.yml").to_obj()[call_name]
        self.url = url
        self.headers = {
            "Content-Type": "application/x-www-form-urlencoded",
            "BCS-APIHub-RequestId": "123456789",
            "X-CHJ-GWToken": self.config["X-CHJ-GWToken"],
        }
        self.timeout = 10

    @retry(tries=1, delay=1)
    def call(self, request_data):
        try:
            response = requests.post(self.url, headers=self.headers, data=request_data, timeout=self.timeout)
            if response.status_code != 200:
                logger.error(
                    f"[ApiHub] response.status_code:{response.status_code}, response.reason:{response.reason}, request_data:{request_data}")
                return None
            response_json = json.loads(response.text)
            return response_json
        except Exception as e:
            logger.error("[EntitySearch] search failed:%s", e)
        return None


if __name__ == "__main__":
    url = "http://csd-api-ontest.inner.chj.cloud/bcs-apihub-tools-proxy-service/tool/v1/ali/ali-finance-us-shares-price"
    call_name = "tool-offline-algorithm"
    obj = ApiHub(url, call_name)
    request_data = {"symbol": "LI"}
    response_json = obj.call(request_data)
    print(json.dumps(response_json, ensure_ascii=False, indent=4))

# python -m utils.tool_utils.api_hub
