import json
import pandas as pd
from retry import retry
from tqdm import tqdm
from utils.llm_utils.serverless_function import request_llm

sys_prompt = """
# 任务描述
你的主要任务是从一句话中提取歌手以及歌曲，这些歌手可以来自电影、音乐等领域。你需要识别出所有提到的歌手名字以及歌曲的名字，并确保提取到的名字是准确的。提取后的结果需要按名字排序。要求能够处理复杂的句子结构，并能够识别多名人物或非典型表达的名字。当一句话中提到一首歌曲并且没有提到具体的歌手时，仅提取歌曲名称并将歌手字段留空（`""`）。提取结果需要保证格式一致，并且歌曲名称中不能包含书名号《》。如果提到多个歌手，则提取所有歌手并放在列表里。

# 输入
输入为一段自然语言的文本，可以包含多个句子，歌曲的名字一般在《》中，也有可能不出现《》。文本中可能会提到一个或多个歌手，每个歌手可能会有不同的称呼，可能是全名、昵称、职务等。

# 提取规则
## 歌曲名提取规则
优先识别带《》的内容，提取后去除书名号《》作为歌曲名；
若未出现《》，需根据语义判断并提取明确指向的歌曲名称（如 “周杰伦的晴天” 中 “晴天” 为歌曲名，“王菲唱的匆匆那年” 中 “匆匆那年” 为歌曲名），避免遗漏无书名号标注的歌曲。
## 歌手名提取规则
基于歌曲名关联的语义信息，提取所有与该歌曲相关的歌手 / 合作歌手 / 制作团队（如 “XX 与 XX 合作的歌曲”“XX、XX 共同演唱的 XX”）；
按歌手在文本中首次出现的顺序提取，存入列表；若未提及任何歌手，则返回包含空字符串 "" 的列表。

# 输出
仅输出提取后的标准 JSON 格式数据，无其他多余内容，确保可直接被解析。

# 示例
示例1：
输入：首先推荐KOKIA的《ありがとう…》，这首作品以细腻的声线诠释日语歌曲特有的情感表达，温暖治愈的旋律令人回味。
输出：
[
  {
    "spoken_name": "ありがとう…",
    "spoken_singer": ["KOKIA"]
  }
]

示例2：
输入：接下来是田馥甄的《小幸运》，钢琴伴奏衬托出少女心事，用自然音域就能唱出青春的悸动与美好。
输出：
[
  {
    "spoken_name": "小幸运",
    "spoken_singer": ["田馥甄"]
  }
]

示例3：
输入：首先推荐魏晨与Nea、HOYO-MiX合作的《不虚此行》，这首流行电子作品用多语种吟唱传递旅途中的澎湃激情，律动节奏如引擎轰鸣般令人热血沸腾。
输出：
[
  {
    "spoken_name": "不虚此行",
    "spoken_singer": ["魏晨","Nea","HOYO-MiX"]
  }
]

示例4：
输入：此外推荐经典民歌《小河淌水》，清泉石上流的意境与婉转悠扬的旋律相融，让人仿佛听见山涧溪流的潺潺声，尽显云南山水之美。
输出：
[
  {
    "spoken_name": "小河淌水",
    "spoken_singer": ""
  }
]
"""
user_prompt = """输入：{spoken}"""


class FindAndParseName():
    def __init__(self):
        self.input_path = "data/cloud_share/recommend/struct_display_new/analyse/analyse_metrics/output_with_entitylink.tsv"
        self.output_path = "data/cloud_share/recommend/struct_display_new/analyse/analyse_metrics/name_and_singer_cal.tsv"
        self.df = pd.read_csv(self.input_path, sep="\t").fillna("")
        self.df_len = len(self.df)

    def process(self):
        self.df['spoken'] = ''
        self.df['spoken_role_list'] = ''
        self.df['title'] = ''
        for idx, row in tqdm(self.df.iterrows(), desc="Processing", total=self.df_len):
            try:
                block = row.get("block", "")
                category = row.get("category", "").strip()
                if not block.strip():
                    continue
                try:
                    block_dict = json.loads(block)
                except Exception as e:
                    print(f"idx: {idx}, block无法解析为JSON, error: {e}")
                    continue
                if category == "音乐":
                    spoken = block_dict.get("spoken", "")
                    if not spoken.strip():
                        continue
                    spoken_role_list = self.parse_role_by_llm(spoken)
                    self.df.loc[idx, 'spoken'] = spoken
                    self.df.loc[idx, 'spoken_role_list'] = json.dumps(spoken_role_list, ensure_ascii=False)
                elif category == "影视":
                    content = block_dict.get("content", {})
                    if isinstance(content, dict):
                        title = content.get("title", "")
                    else:
                        title = block_dict.get("title", "")
                    self.df.loc[idx, 'title'] = title
            except Exception as e:
                print(f"idx: {idx}, error: {e}, block: {row.get('block', '')}")
                continue

        self.df.to_csv(self.output_path, sep="\t", index=False)
        print(f"文件已成功保存至： {self.output_path}")
        print(f"输出文件包含列：{list(self.df.columns)}")

    @retry((Exception,), tries=5, delay=1)
    def parse_role_by_llm(self, spoken: str):
        try:
            _, res = request_llm([sys_prompt, user_prompt.format(spoken=spoken)])
            content = res["choices"][0]["message"]["content"]
            if content.startswith("```json"):
                content = content[7:]
            if content.endswith("```"):
                content = content[:-3]
            content = content.strip()
            response = json.loads(content)
            if isinstance(response, list):
                for role in response:
                    if isinstance(role, dict):
                        role["spoken_name"] = role.get("spoken_name", "").strip("《》")
                        singer = role.get("spoken_singer", None)
                        if isinstance(singer, str):
                            role["spoken_singer"] = [singer]
                        elif isinstance(singer, list):
                            role["spoken_singer"] = singer
                return response
            else:
                return []
        except Exception as e:
            print(f"LLM parse error for: {spoken}, error: {e}")
            return []


if __name__ == "__main__":
    obj = FindAndParseName()
    obj.process()

    # python -m utils.tool_utils.find_song_name_utils
