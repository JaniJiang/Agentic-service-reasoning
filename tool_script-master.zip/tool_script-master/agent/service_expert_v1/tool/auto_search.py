import asyncio
import json
import time
from typing import List

import requests
from agentscope.message import TextBlock
from agentscope.tool import ToolResponse


async def auto_search(query: str, tag_list: List[str]) -> ToolResponse:
    """查询汽车相关知识，涵盖车辆状态、功能操作、故障处理等多个维度，并且也包括通用汽车知识。
    Args:
        query (`str`): 搜索查询
        tag_list (`List[str]`): 标签列表，从query中抽取的标签
    Returns:
        `ToolResponse`: 工具结果
    """
    url = "http://ks-engine-server-inference.ssai-apis-staging.chj.cloud:80/cloud/inner/nlp/kg/knowledge-search-engine/search"
    payload = json.dumps(
        {
            "metadata": {
                "passengers": {
                    "passengers": [
                        {
                            "id": "platform_dvbSPpwzSVM6",
                            "ceip": True,
                            "age": 28,
                            "nickName": "刘若旋",
                            "speakerVerificationId": "platform_ltwd6VgZX7td",
                            "speakerSeat": "SPEAKER_SEAT_FIRST_LEFT",
                            "faceId": "platform_7pHqfTPkAiO0",
                            "accountId": "platform_32DdLaayIyXf",
                        }
                    ]
                },
                "dynamicInfo": {
                    "position": {"latitude": 39.865246, "longitude": 116.37852, "city": "北京市", "coordinate": "wgs84"}
                },
                "vehicleInfo": {
                    "manufacturer": "liauto",
                    "vehicleConfigCode": "255,32,6,32,48,249,255,105,253,28,95,251,1,32,226,239,175",
                    "huOtaVersion": "1.0",
                    "userManualVersion": "10",
                    "helpAppVersion": "5000001",
                    "vin": "dialog_platform_lmy",
                    "vehicleModel": "VEHICLE_MODEL_X01",
                    "spu": "ss2pro",
                    "voiceVersion": "8.0.0.5",
                    "accountId": "dialog_platform_lmy",
                },
                "requestInfo": {
                    "msgId": "platform_1meOKW61HFsyj9lK3D73Ztest",
                    "sessionId": "7y8bF37JJ_m4PoTzzQmxV",
                    "trackId": "1JCXPik_rXV1JxSl86BSM",
                },
                "appInfo": {"category": "com.chehejia.car.voice"},
            },
            "origQuery": query,
            "searchQuery": query,
            "searchCategory": ["汽车"],
            "searchSlots": {"tag": tag_list, "slots": {"TAG": {"item": tag_list}}},
            "searchBot": "kg-bot",
            "freshness": True,
            "timeSlots": {},
            "function": {},
        }
    )
    headers = {"User-Agent": "Apifox/1.0.0 (https://www.apifox.cn)", "Content-Type": "application/json"}

    max_retries = 3
    retries = 0
    result_text = ""
    while retries < max_retries:
        try:
            response = requests.request("POST", url, headers=headers, data=payload, timeout=10)
            response_json = response.json()
            response_data = response_json.get("data", [])
            if len(response_data) > 0:
                bot_data = response_data[0].get("bot_data", [])
                if len(bot_data) > 0:
                    result_list = []
                    for item in bot_data:
                        result_list.append(
                            {
                                "title": item.get("title", ""),
                                "content": item.get("content", ""),
                                "authority": item.get("authority", ""),
                                "doc_source": item.get("doc_source", ""),
                                "date_published": item.get("date_published", ""),
                            }
                        )
                    result_text = json.dumps(result_list, ensure_ascii=False)
                    break
        except Exception:
            retries += 1
            time.sleep(1)
    return ToolResponse(content=[TextBlock(type="text", text=result_text)])


if __name__ == "__main__":
    query = "如何打开天窗？"
    tag_list = ["天窗"]
    result = asyncio.run(auto_search(query, tag_list))
    print(result)

# python tool/auto_search.py
