import asyncio
import json
import time

import requests
from agentscope.message import TextBlock
from agentscope.tool import ToolResponse


async def qa_bot(query: str) -> ToolResponse:
    """查询用车助手相关知识，涵盖车辆状态、功能操作、故障处理等多个维度。
    Args:
        query (`str`): 搜索查询
    Returns:
        `ToolResponse`: 工具结果
    """
    url = "http://cockpit-qabot-lids-testtwo.ssai-apis-staging.chj.cloud:80/expert/query"
    payload = json.dumps(
        {
            "msgId": "platform_kk",
            "aiUserId": "wzy",
            "timestamp": 1730168715678,
            "voiceVersion": "6.4.0.0",
            "topK": 20,
            "extendData": {
                "vehicleConfigCode": "1,81,1,35,65,249,255,255,252,255,31,31,1,255,1,255,175",
                "vehicleModel": "X03",
                "userManualVersion": "10",
                "appVersion": {"help": "5000001"},
                "huOtaVersion": "1.0",
                "nightMode": 0,
                "spu": "ss2pro",
            },
            "input": {"text": query, "voiceImage": {"position": 0}},
        }
    )
    headers = {"User-Agent": "Apifox/1.0.0 (https://www.apifox.cn)", "Content-Type": "application/json"}

    max_retries = 3
    retries = 0
    result_text = ""
    while retries < max_retries:
        try:
            response = requests.request("POST", url, headers=headers, data=payload, timeout=10)
            response_json = response.json()
            response_data = response_json.get("data", [])
            if len(response_data) > 0:
                result_list = []
                for item in response_data[:3]:  # 只取前三条结果
                    result_list.append(
                        {
                            # "question": item.get("question", "").strip(),
                            # "expand_question": item.get("expandQuestion", "").strip(),
                            "question": item.get("expandQuestion", "").strip(),
                            "answer": item.get("answer", "").strip(),
                        }
                    )
                result_text = json.dumps(result_list, ensure_ascii=False)
                break
        except Exception:
            retries += 1
            time.sleep(1)
    return ToolResponse(content=[TextBlock(type="text", text=result_text)])


if __name__ == "__main__":
    query = "如何打开天窗？"
    result = asyncio.run(qa_bot(query))
    print(result)

# python tool/qa_bot.py
