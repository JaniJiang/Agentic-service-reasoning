import pandas as pd

from mcp_tools.search_tool.eval.meta import *


class CalculateToolV2Metrics:
    def __init__(self):
        self.input_path = (
            f"{DATA_DIR}/{EVAL_VERSION}_{EVAL_MODE}/{EVAL_CATEGORY}/step2_prelabel_search_result.labeled.tsv"
        )
        print(f"[{EVAL_CATEGORY}]")

    def process(self):
        df = pd.read_csv(self.input_path, sep="\t").fillna("")

        # 分析平均结果条数
        media_total_len = df["线上结果条数"].sum() / len(df)
        media_right_len = df["线上正确条数"].sum() / len(df)
        custom_total_len = df["自建结果条数"].sum() / len(df)
        custom_right_len = df["自建正确条数"].sum() / len(df)
        merge_total_len = (df["线上结果条数"].sum() + df["自建结果条数"].sum()) / len(df)
        merge_right_len = (df["线上正确条数"].sum() + df["自建正确条数"].sum()) / len(df)
        print("media_total_len:", round(media_total_len, 2))
        print("media_right_len:", round(media_right_len, 2))
        print("custom_total_len:", round(custom_total_len, 2))
        print("custom_right_len:", round(custom_right_len, 2))
        print("merge_total_len:", round(merge_total_len, 2))
        print("merge_right_len:", round(merge_right_len, 2))

        # 分析准确率和聚类问题
        media_acc_list = []
        media_p_list = []
        custom_acc_list = []
        custom_p_list = []
        merge_acc_list = []
        merge_p_list = []
        media_case_dict = {}
        custom_case_dict = {}
        for _, row in df.iterrows():
            # 准确率
            media_total_count = row["线上结果条数"]
            media_right_count = row["线上正确条数"]
            custom_total_count = row["自建结果条数"]
            custom_right_count = row["自建正确条数"]
            merge_total_count = media_total_count + custom_total_count
            merge_right_count = media_right_count + custom_right_count
            if media_total_count > 0:
                media_acc = media_right_count / media_total_count
                media_acc_list.append(media_acc)
                media_p = 1 if media_right_count > 0 else 0
                media_p_list.append(media_p)
            if custom_total_count > 0:
                custom_acc = custom_right_count / custom_total_count
                custom_acc_list.append(custom_acc)
                custom_p = 1 if custom_right_count > 0 else 0
                custom_p_list.append(custom_p)
            if merge_total_count > 0:
                merge_acc = merge_right_count / merge_total_count
                merge_acc_list.append(merge_acc)
                merge_p = 1 if merge_right_count > 0 else 0
                merge_p_list.append(merge_p)
            # 聚类问题
            media_case_dict = self.parse_case(media_case_dict, row["线上问题类型"])
            custom_case_dict = self.parse_case(custom_case_dict, row["自建问题类型"])
        # 输出准确率指标
        media_acc_rate = sum(media_acc_list) / len(media_acc_list)
        media_p_rate = sum(media_p_list) / len(media_p_list)
        custom_acc_rate = sum(custom_acc_list) / len(custom_acc_list)
        custom_p_rate = sum(custom_p_list) / len(custom_p_list)
        merge_acc_rate = sum(merge_acc_list) / len(merge_acc_list)
        merge_p_rate = sum(merge_p_list) / len(merge_p_list)
        print("media_acc_rate:", round(media_acc_rate, 4))
        print("media_p_rate:", round(media_p_rate, 4))
        print("custom_acc_rate:", round(custom_acc_rate, 4))
        print("custom_p_rate:", round(custom_p_rate, 4))
        print("merge_acc_rate:", round(merge_acc_rate, 4))
        print("merge_p_rate:", round(merge_p_rate, 4))
        # 输出聚类问题占比
        print("media_case_dict:", media_case_dict)
        print("custom_case_dict:", custom_case_dict)

    def parse_case(self, case_dict, case_str):
        if case_str.strip() == "":
            return case_dict
        for x in case_str.strip().split("\n"):
            if x.strip() == "":
                continue
            case_type, case_count = x.strip().split("：")
            if case_type not in case_dict:
                case_dict[case_type] = 0
            case_dict[case_type] += int(case_count)
        return case_dict


if __name__ == "__main__":
    obj = CalculateToolV2Metrics()
    obj.process()

# python -m mcp_tools.search_tool.eval.step3_calculate_tool_v2_metrics
