import os
import json
import pandas as pd
from tqdm import tqdm
from loguru import logger
from mcp_tools.search_tool.eval.meta import *
from utils.http_client import HTTPClient


class BuildEvalData:

    def __init__(self):
        self.input_path = f"{DATA_DIR}/{EVAL_VERSION}_{EVAL_MODE}/eval_input.tsv"
        self.output_path = f"{DATA_DIR}/{EVAL_VERSION}_{EVAL_MODE}/eval_output.tsv"
        os.makedirs(os.path.dirname(self.output_path), exist_ok=True)
        self.need_sample = False

    def process(self):
        # 读取数据
        input_df = pd.read_csv(self.input_path, sep="\t").fillna("")
        # 随机部分数据做评估
        if self.need_sample is True:
            output_df = input_df.sample(frac=0.2, random_state=42)
        else:
            output_df = input_df
        # 逐条请求规划服务获取tool_calls
        for idx, row in tqdm(output_df.iterrows(), total=len(output_df)):
            # 构造请求参数
            request_params = self.build_request_params_v3(row)
            # 请求规划服务
            http_client_obj = HTTPClient(DEEP_PLAN_URL)
            try:
                response_dict = http_client_obj.request(request_params)
                tool_calls = response_dict["messages"][0]["tool_calls"]
            except Exception as e:
                tool_calls = []
                logger.warning(f"[BuildEvalData] HTTPClient process failed: {e}")
            # 保存结果
            output_df.loc[idx, "tool_calls"] = json.dumps(tool_calls, ensure_ascii=False, indent=4)
        output_df.to_csv(self.output_path, sep="\t", header=True, index=False)

    def build_request_params_v1(self, row):
        """20251110提供：初版模型"""
        return {
            "messages": [
                {
                    "role": "user",
                    "content": row["query"]
                }
            ]
        }

    def build_request_params_v2(self, row):
        """20251119提供：使用传入的lpai模型"""
        return {
            "plan_model": {
                "url": "https://lpai-inference-guan.inner.chj.cloud/inference/ss-sai/deep-plan-sft-qwen-47d9-cgjroi/v1",
                "model": "deep-plan-sft-qwen"
            },
            "messages": [
                {
                    "role": "system",
                    "content": "# metadata\n{}"
                },
                {
                    "role": "user",
                    "content": row["query"]
                }
            ]
        }

    def build_request_params_v3(self, row):
        """20251126提供：plan_mode置空，会默认调用testtwo的最新模型"""
        return {
            "plan_model": {
                "url": "",
                "model": ""
            },
            "messages": [
                {
                    "role": "system",
                    "content": "# metadata\n{}"
                },
                {
                    "role": "user",
                    "content": row["query"]
                }
            ],
            "tools": []
        }


if __name__ == "__main__":
    obj = BuildEvalData()
    obj.process()

# python -m mcp_tools.search_tool.eval.step0_build_eval_data
# nohup python -m mcp_tools.search_tool.eval.step0_build_eval_data > log/mcp_tools/search_tool/eval/step0_build_eval_data.log 2>&1 &
