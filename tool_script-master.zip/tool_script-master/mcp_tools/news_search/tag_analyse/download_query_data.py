"""
DataGridLoader --> dataset_loader.py --> read_in_batches_as_iterator() --> line1660:

    else:
        all_batches = []
        for batch in scanner.scan_batches():
            # Convert the PyArrow RecordBatch to pandas DataFrame
            df_batch = batch.record_batch.to_pandas()
            all_batches.append(df_batch)

        # 合并所有 batch
        df_all = pd.concat(all_batches, ignore_index=True) if all_batches else pd.DataFrame()

        if process_func:
            result = process_func(df_all)
            yield result
        else:
            yield df_batch
"""

import os
import json
import pandas as pd
from tqdm import tqdm
from datagrid import get_client
from multiprocessing import Pool
from datetime import datetime, timedelta


EXCLUDE_KEYWORDS = [
    "热点", "热搜", "微博", "头条", "关闭",
    "早间", "午间", "晚间", "国际", "国内", "国外",
    "政治", "经济", "财经", "军事", "科技",
    "体育", "教育", "民生", "娱乐", "时政", "时事"
]


def build_exclude_sql(field: str, keywords: list[str]) -> str:
    return "\n".join(
        f"AND {field} NOT LIKE '%{kw}%'"
        for kw in keywords
    )


def sql_filter_func(df: pd.DataFrame) -> pd.DataFrame:
    df = df[['record_id', 'query', 'content']].copy()
    df = df[df['query'].notna() & (df['query'].str.strip() != '') & df['content'].notna()]
    if df.empty:
        return df

    def validate_json(x):
        try:
            j = json.loads(x)
            return j.get('APINAME') == 'MEDIASearch' and j.get('MEDIATYPE') == '新闻'
        except Exception:
            return False

    df = df[df['content'].apply(validate_json)]
    return df


def dedup_data(df: pd.DataFrame) -> pd.DataFrame:
    df = df[df['query'].notna()]
    df = df[df['query'].str.strip() != '']
    df = df.drop_duplicates(subset=['query'], keep='first')
    return df


def process_one_day(dt_str: str):
    out_date = dt_str.replace("-", "")
    output_file = f"/lpai/volumes/ss-sai-bd-ga/liwenjing3/code/tool_script/data/cloud_share/mcp_tools/tag_analyse/{out_date}.tsv"

    if os.path.exists(output_file):
        return f"{dt_str} skipped"

    try:
        os.environ['dip.env'] = 'prod'
        os.environ['dip.x-dip-spacecode'] = 'sai-dp'
        os.environ['dip_refresh_token'] = 'BJ:7yqCc1aWCIZnrRuOqGD'
        os.environ['dip.x-chj-gwtoken'] = (
            'eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9.'
            'eyJpc3MiOiJud01DajhpZm9FMEFTZVFrVkF5V2dBUThQVHpldmJMaSJ9.'
            'BS9D24qhhIW-96wecYvgLCWicOvIeym-IeWk6xDf3pQ'
        )

        client = get_client(
            env=os.environ['dip.env'],
            space_code=os.environ['dip.x-dip-spacecode'],
            refresh_token=os.environ['dip_refresh_token'],
            x_chj_gwtoken=os.environ['dip.x-chj-gwtoken']
        )

        database = "ssai_ods"
        table = "dwd_ssai_merge_voice_prod"
        partition_spec = f"dt={dt_str}"

        exclude_sql = build_exclude_sql("query", EXCLUDE_KEYWORDS)
        filter = f"""
            SELECT record_id, query, content
            FROM ssai_ods.dwd_ssai_merge_voice_prod
            WHERE dt = '{dt_str}'
            AND content IS NOT NULL
            AND content LIKE '%"APINAME":"MEDIASearch"%'
            AND content LIKE '%"MEDIATYPE":"新闻"%'
            AND query IS NOT NULL
            {exclude_sql}
        """

        df_iterator = client.load_table_in_iterator(
            database=database,
            table=table,
            partition_spec=partition_spec,
            filter_expression=filter,
            process_func=sql_filter_func,
            batch_size=10_000_000,
            verbose=False,
            progress=False
        )

        dfs = [df for df in df_iterator]
        if not dfs:
            return f"{dt_str} empty"

        merged_df = pd.concat(dfs, ignore_index=True)
        filtered_df = dedup_data(merged_df)

        filtered_df.to_csv(output_file, sep="\t", index=False)
        return f"{dt_str} done ({len(filtered_df)})"

        print(
            f"[{dt_str}] "
            f"raw_rows={len(merged_df)}, "
            f"dedup_rows={len(filtered_df)}"
        )

    except Exception as e:
        return f"{dt_str} failed: {e}"


if __name__ == "__main__":
    start_date = datetime.strptime("2025-12-01", "%Y-%m-%d")
    end_date = datetime.strptime("2025-12-15", "%Y-%m-%d")

    date_list = []
    cur = start_date
    while cur <= end_date:
        date_list.append(cur.strftime("%Y-%m-%d"))
        cur += timedelta(days=1)

    processes = 4

    results = []
    with Pool(processes=processes) as pool:
        for res in tqdm(
            pool.imap_unordered(process_one_day, date_list),
            total=len(date_list),
            desc="Processing dates",
        ):
            results.append(res)

    print("\n=== 执行结果汇总 ===")
    for r in sorted(results):
        print(r)

    # python -m mcp_tools.news_search.tag_analyse.down_query_data
