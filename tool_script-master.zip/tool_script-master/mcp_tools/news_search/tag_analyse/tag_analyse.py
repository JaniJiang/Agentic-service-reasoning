import os
import glob
import jieba
import pandas as pd
from collections import Counter


class TagAnalyse():
    def __init__(self):
        self.input_path = "/lpai/volumes/ss-sai-bd-ga/liwenjing3/code/tool_script/data/cloud_share/mcp_tools/tag_analyse"
        self.stopwords_dir = os.path.join(self.input_path, "stopwords")
        self.output_dir = os.path.join(self.input_path, "outputs")

        self.stopwords_files = [
            "news_stopwords.txt",
            "baidu_stopwords.txt",
            "cn_stopwords.txt",
            "hit_stopwords.txt",
            "scu_stopwords.txt"
        ]
        self.stop_words = self.load_stop_words()

    def load_stop_words(self):
        stop_words = set()

        for fname in self.stopwords_files:
            fpath = os.path.join(self.stopwords_dir, fname)
            with open(fpath, "r", encoding="utf-8") as f:
                for line in f:
                    stop_word = line.strip()
                    if not stop_word:
                        continue
                    stop_words.add(stop_word)

        return stop_words

    def read_all_tsv(self):
        pattern = os.path.join(self.input_path, "*.tsv")
        files = sorted(glob.glob(pattern))
        if not files:
            raise FileNotFoundError("no tsv files found in {}".format(self.input_path))

        dfs = []
        for file in files:
            print("reading:", file)
            df = pd.read_csv(file, sep="\t")
            needed_cols = ["record_id", "query", "content"]
            for col in needed_cols:
                if col not in df.columns:
                    raise ValueError("{} missing column: {}".format(file, col))
            dfs.append(df[needed_cols])

        all_df = pd.concat(dfs, ignore_index=True)
        return all_df

    def tokenize_and_count(self, queries, top_k=200):
        counter = Counter()
        for query in queries:
            query = query.strip()
            tokens = jieba.lcut(query)

            for token in tokens:
                token = token.strip()
                if token in self.stop_words:
                    continue
                counter[token] += 1

        return counter.most_common(top_k)

    def process(self):
        df = self.read_all_tsv()
        print("total rows:", len(df))

        queries = df["query"].tolist()
        top_words = self.tokenize_and_count(queries, top_k=200)

        for word, freq in top_words:
            print("{}\t{}".format(word, freq))

        out_path = os.path.join(self.output_dir, "query_top_words.tsv")
        pd.DataFrame(top_words, columns=["word", "freq"]).to_csv(
            out_path, sep="\t", index=False
        )
        print("saved to:", out_path)


if __name__ == "__main__":
    obj = TagAnalyse()
    obj.process()
    # python -m mcp_tools.news_search.tag_analyse.tag_analyse
