from utils.data_utils.data_trans import *
from mcp_tools.doc_process.train_model.meta import *
from utils.llm_utils.chat_with_lapi_LLM import *
from concurrent.futures import ThreadPoolExecutor
from tqdm import tqdm
import json
import re


def parse_think_and_json(text):
    result = {"think": None, "json": None}
    text = text.replace("'", '"')

    think_match = re.search(r'<think>(.*?)</think>', text, re.DOTALL)
    if think_match:
        result["think"] = think_match.group(1).strip()

    json_match = re.search(r'```json\s*(.*?)\s*```', text, re.DOTALL)
    if json_match:
        try:
            result["json"] = json.loads(json_match.group(1))
        except Exception:
            result["json"] = None
    return result


class Eval:
    def __init__(self):
        self.model = "dp-4-full-qwen3-8b"
        self.input_path = "data/cloud_share/mcp_tools/doc_process/train_data/eval_data/test_0109.tsv"
        self.output_path = "data/cloud_share/mcp_tools/doc_process/train_data/eval_data/test_0109_label_old.tsv"

        self.df = load_any_to_dataframe(self.input_path)
        self.df_len = len(self.df)

    def safe_load_json(self, text: str):
        if not text or not text.strip():
            return "NONE"

        text = re.sub(r"```json|```", "", text).strip()
        try:
            return json.loads(text)
        except json.JSONDecodeError:
            try:
                text_fixed = text.replace("\n", "\\n").replace("\r", "\\r")
                return json.loads(text_fixed)
            except json.JSONDecodeError:
                try:
                    def repl(m):
                        return m.group(0).replace("\n", "\\n").replace("\r", "\\r")

                    text_fixed = re.sub(r'("(?:[^"\\]|\\.)*")', repl, text)
                    return json.loads(text_fixed)
                except json.JSONDecodeError:
                    return "NONE"

    def _process_one(self, args):
        idx, row = args
        try:
            title = row["title"]
            content = row["content"].replace('"', "'")

            res0 = chat_with_lpai_LLM_signal(
                system_prompt.format(title=title, content=content),
                self.model,
                llm_config[self.model],
                temperature=0
            )
            print(res0)

            if not res0 or not res0.strip():
                print(f"[EMPTY RESPONSE] idx={idx}")
                return idx, None

            res = self.safe_load_json(res0)
            if res == "NONE" or not isinstance(res, dict):
                print(f"[JSON FAIL] idx={idx}")
                print("RAW:", repr(res0[:300]))
                return idx, None

            return idx, {
                "quality_pred": res.get("quality"),
                "features_pred": res.get("features"),
                "summary_pred": res.get("summary"),
                "time_pred": res.get("time"),
            }

        except Exception as e:
            print(f"[EXCEPTION] idx={idx} err={e}")
            return idx, None

    def process(self, max_workers=4):
        for col in ("quality_pred", "features_pred", "summary_pred", "time_pred"):
            self.df[col] = None

        tasks = [(idx, row) for idx, row in self.df.iterrows()]

        with ThreadPoolExecutor(max_workers=max_workers) as executor:
            for idx, result in tqdm(
                executor.map(self._process_one, tasks),
                total=self.df_len,
                desc="Processing"
            ):
                if result is None:
                    continue
                for k, v in result.items():
                    self.df.at[idx, k] = v

        self.df.to_csv(self.output_path, sep="\t", index=False)
        print(f"文件已成功保存至： {self.output_path}")


if __name__ == "__main__":
    obj = Eval()
    obj.process(max_workers=8)

# python -m mcp_tools.doc_process.train_model.step2_eval_data_v2
