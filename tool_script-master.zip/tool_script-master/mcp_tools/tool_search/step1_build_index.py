import re
import json
import csv
import hashlib
import pandas as pd
from tqdm import tqdm
from loguru import logger
from utils.nlp_utils.embedding_client_new import EmbeddingClient
from mcp_tools.tool_search.meta import *


class BuildIndex:
    def __init__(self):
        self.input_path = f"{DATA_DIR}/tool_schema_v2.tsv"
        self.output_path = f"{DATA_DIR}/step1_build_tool_index.jsonl"
        self.embedding_client = EmbeddingClient(vector_dim=TOOL_DIM)
        if INDEX_QUERY_FLAG:
            self.index_query_input = f"{DATA_DIR}/index_query.tsv"
            self.index_query_output = f"{DATA_DIR}/step1_build_query_index.jsonl"
            self.index_query_client = EmbeddingClient(vector_dim=TOOL_DIM)

    def build_embed_text(self, func: dict) -> str:
        name = func.get("tool_name", "")
        name_zh = func.get("tool_name_zh", "")
        intro = func.get("tool_intro", "")
        desc = func.get("tool_desc", "")
        # base_text = f"{name}：{desc}。".strip()  # v2: 不带中文名
        # base_text = f"{name}({name_zh})：{desc}。".strip()  # v2: 带中文名

        if EMBED_VERSION == "v7":
            base_text = f"{name}；{desc}".strip()
            base_text = base_text.replace('\r\n', ' ').replace('\n', ' ')
            print(base_text)

            return base_text

        if EMBED_VERSION == "v1":
            base_text = f"{name} {desc}".strip()
            return base_text

        if EMBED_VERSION == "v4":
            parts = []
            if name_zh:
                parts.append(name_zh)
            if intro:
                parts.append(intro)
            if desc:
                parts.append(desc)
            base_text = "；".join(parts).strip()
            base_text = base_text.replace('\r\n', ' ').replace('\n', ' ')
            print(base_text)

            return base_text

        if EMBED_VERSION == "v2":
            params = func.get("tool_params", {}) or {}
            required = params.get("required", []) or []
            # required = [field for field in required if field != "position"]  # v2.1
            # required = [field for field in required if (
            #     field != "position" and field != "query" and field != "oriQuery" and field != "searchQuery" and field != "text")]  # v2.2
            properties = params.get("properties", {}) or {}

            if not required:
                return base_text
            required_names = "、".join(required)

            field_desc_list = []
            for field in required:
                field_schema = properties.get(field, {})
                field_desc = field_schema.get("description", "")
                if field_desc:
                    field_desc_list.append(f"{field}：{field_desc}")

            required_text = f"必填字段包括{required_names}。"
            if field_desc_list:
                required_text += "。".join(field_desc_list) + "。"
            print(f"{base_text} {required_text}".strip())
            return f"{base_text} {required_text}".strip()

        return base_text

    def process(self):
        items = []
        with open(self.input_path, "r", encoding="utf-8") as f:
            reader = csv.DictReader(f, delimiter="\t")

            for row in reader:
                if not (name := row.get("name")) or not (schema_str := row.get("schema")):
                    print(1)
                    continue

                try:
                    func = json.loads(schema_str)
                    embed_text = self.build_embed_text(func)
                    if embed_text:
                        items.append({
                            "index_id": func.get("tool_id", ""),
                            "name": name,
                            "text": embed_text,
                            "payload": {
                                "tool_name": name,
                                "tool_type": func.get("tool_type", "")
                            }
                        })
                except Exception as e:
                    logger.warning(f"Parse tsv row failed (name: {name}): {e}")
                    continue

        # query emb
        if INDEX_QUERY_FLAG:
            df_q = pd.read_csv(self.index_query_input, sep="\t")
            df_q = df_q.dropna(subset=["query"])
            logger.info(f"Load {len(df_q)} valid queries")
            with open(self.index_query_output, "w", encoding="utf-8") as fq:
                for _, row in tqdm(df_q.iterrows(), total=len(df_q), desc="Building query index"):
                    text = str(row["query"]).strip()
                    if not text:
                        continue
                    vec = self.index_query_client.embed(text)
                    if (not vec) or len(vec) != TOOL_DIM:
                        logger.warning(
                            f"Query embedding dim mismatch, expect={TOOL_DIM}, got={len(vec) if vec else 0}, skip query")
                        continue
                    item = {
                        "id": self.generate_index_id(text),
                        "tool_type": row.get("工具类型") if "工具类型" in df_q.columns else row.get("tool_type", ""),
                        "tool": row.get("tool", ""),
                        "query": text,
                        "vector": vec,
                        "payload": {
                            "tool_name": row.get("tool", ""),
                            "tool_type": row.get("工具类型", "")
                        }
                    }
                    fq.write(json.dumps(item, ensure_ascii=False) + "\n")
            logger.info(f"Build query index finished successfully: {self.index_query_output}")

        # tool emb
        logger.info(f"Load {len(items)} valid tools")

        if not items:
            logger.warning("No valid tool schema found, exit process")
            return

        with open(self.output_path, "w", encoding="utf-8") as f:
            for batch_start in tqdm(range(0, len(items), BATCH_SIZE), desc="Building tool index"):
                batch_items = items[batch_start:batch_start + BATCH_SIZE]
                batch_texts = [item["text"] for item in batch_items]

                embeddings = []
                for text in batch_texts:
                    vec = self.embedding_client.embed(text)
                    if not vec:
                        embeddings.append(None)
                    else:
                        embeddings.append(vec)

                for idx, item in enumerate(batch_items):
                    embedding = embeddings[idx]
                    if not embedding or len(embedding) != TOOL_DIM:
                        logger.warning(
                            f"Embedding dim mismatch, expect={TOOL_DIM}, got={len(embedding) if embedding else 0}, skip item")
                        continue

                    qdrant_item = {
                        "id": item["index_id"],
                        "query": item["name"],
                        "index_text": item["text"],
                        "vector": embedding,
                        "payload": item["payload"]
                    }

                    f.write(json.dumps(qdrant_item, ensure_ascii=False) + "\n")

        logger.info(f"Build tool index finished successfully: {self.output_path}")

    @staticmethod
    def generate_index_id(name: str) -> str:
        return hashlib.md5(name.encode("utf-8")).hexdigest()


if __name__ == "__main__":
    obj = BuildIndex()
    obj.process()

# python -m mcp_tools.tool_search.step1_build_index
