# 路径
DATA_DIR = "data/cloud_share/mcp_tools/tool_search"

# 向量模型参数
EMBED_VERSION = "v4"
QUERY_DIM = 128
TOOL_DIM = 128
BATCH_SIZE = 1
MODEL_TYPE = "bge-m3"
INDEX_QUERY_FLAG = True

# 召回参数
RECALL_STRATEGY = "v4"
RECALL_NUM = 5
RECALL_NUM_CAR = 2
RECALL_NUM_ClOUD = 2
RECALL_NUM_DEFAULT = 1
DEFAULT_TOOL_NAME = "general_search"
