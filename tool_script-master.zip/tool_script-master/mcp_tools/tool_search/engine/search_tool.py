import csv
import json
import requests
from typing import List, Dict


class ToolRetrieverEvaluator:
    def __init__(self):
        self.input_path = "data/cloud_share/mcp_tools/tool_search/engine/query.tsv"
        self.output_path = "data/cloud_share/mcp_tools/tool_search/engine/tool_retriever_result.tsv"
        self.search_url = "http://ssai-data-center-lids-testtwo.ssai-apis-staging.chj.cloud/ssai-data-center/v1/tool/agent-tool/search"

    def read_queries(self) -> List[Dict]:
        queries = []
        with open(self.input_path, "r", encoding="utf-8") as f:
            reader = csv.DictReader(f, delimiter="\t")
            for row in reader:
                queries.append(row)
        return queries

    def search(self, query: str) -> List[Dict]:
        payload = {"msg_id": "test_search_tool", "query": query}
        try:
            resp = requests.post(self.search_url, json=payload, timeout=10)
            if resp.status_code != 200:
                print(f"HTTP {resp.status_code} for query '{query}'")
                return []
            data = resp.json().get("data", [])
            result = [
                {
                    "toolName": item.get("toolName"),
                    "toolIndexText": item.get("toolIndexText"),
                    "score": item.get("score")
                }
                for item in data
            ]
            result.sort(key=lambda x: x["score"], reverse=True)
            return result
        except Exception as e:
            print(f"Search error for query '{query}': {e}")
            return []

    def evaluate_tool_position(self, result: List[Dict], target_tool: str) -> Dict:
        pos = -1
        score = 0
        for i, item in enumerate(result, start=1):
            if item["toolName"] == target_tool:
                pos = i
                score = item["score"]
                break
        acc3 = 1 if pos != -1 and pos <= 3 else 0
        acc5 = 1 if pos != -1 and pos <= 5 else 0
        return {"pos": pos, "score": score, "acc3": acc3, "acc5": acc5}

    def process(self):
        queries = self.read_queries()
        if not queries:
            print("No queries found.")
            return

        output_rows = []
        total_acc3 = 0
        total_acc5 = 0

        for row in queries:
            tool_type = row.get("工具类型") or row.get("tool_type") or ""
            tool = row.get("tool") or ""
            query_text = row.get("query") or ""

            results = self.search(query_text)
            eval_info = self.evaluate_tool_position(results, tool)

            total_acc3 += eval_info["acc3"]
            total_acc5 += eval_info["acc5"]

            output_rows.append({
                "tool_type": tool_type,
                "tool": tool,
                "query": query_text,
                "tool_retriever_result": json.dumps(results, ensure_ascii=False, indent=4),
                "tool_pos": eval_info["pos"],
                "tool_score": eval_info["score"],
                "tool_acc@3": eval_info["acc3"],
                "tool_acc@5": eval_info["acc5"]
            })

        num_queries = len(queries)
        print(f"Overall acc@3: {total_acc3 / num_queries:.3f}")
        print(f"Overall acc@5: {total_acc5 / num_queries:.3f}")

        with open(self.output_path, "w", encoding="utf-8", newline="") as f:
            fieldnames = ["tool_type", "tool", "query", "tool_retriever_result",
                          "tool_pos", "tool_score", "tool_acc@3", "tool_acc@5"]
            writer = csv.DictWriter(f, fieldnames=fieldnames, delimiter="\t")
            writer.writeheader()
            for row in output_rows:
                writer.writerow(row)

        print(f"Evaluation results saved to {self.output_path}")


if __name__ == "__main__":
    obj = ToolRetrieverEvaluator()
    obj.process()

# python -m mcp_tools.tool_search.engine.search_tool
