import csv
import json
import requests
from typing import List


class DeleteTool:
    def __init__(self):
        self.input_path = "data/cloud_share/mcp_tools/tool_search/engine/tool_schema.tsv"
        self.delete_url = "http://ssai-data-center-lids-testtwo.ssai-apis-staging.chj.cloud/ssai-data-center/v1/agent-tool-admin/delete"
        self.msg_id = "test_delete_tool"

    def read_tool_ids(self) -> List[str]:
        tool_ids = []

        with open(self.input_path, "r", encoding="utf-8") as f:
            reader = csv.DictReader(f, delimiter="\t")
            for row in reader:
                schema_str = row.get("schema")
                if not schema_str:
                    continue

                schema = json.loads(schema_str)
                tool_id = schema.get("tool_id")
                if tool_id:
                    tool_ids.append(tool_id)

        return tool_ids

    def chunk_list(self, data: List[str], chunk_size: int = 10):
        for i in range(0, len(data), chunk_size):
            yield data[i:i + chunk_size]

    def delete(self, tool_ids: List[str]):
        payload = {
            "msg_id": self.msg_id,
            "tool_ids": tool_ids,
        }

        resp = requests.post(
            self.delete_url,
            json=payload,
            timeout=10,
        )

        if resp.status_code != 200:
            print("HTTP Status:", resp.status_code)
            print("Response Text:", resp.text)
            resp.raise_for_status()

        return resp.json()

    def process(self):
        tool_ids = self.read_tool_ids()
        if not tool_ids:
            print("No tool_id found.")
            return

        print(f"Total tools to delete: {len(tool_ids)}")

        for idx, batch in enumerate(self.chunk_list(tool_ids, 10), start=1):
            print(f"Deleting batch {idx}, size={len(batch)}")
            print("Tool IDs:", batch)

            try:
                result = self.delete(batch)
                print(f"Batch {idx} success: {result}")
            except Exception as e:
                print(f"Batch {idx} failed: {e}")
                break


if __name__ == "__main__":
    obj = DeleteTool()
    obj.process()

# python -m mcp_tools.tool_search.engine.delete_tool
