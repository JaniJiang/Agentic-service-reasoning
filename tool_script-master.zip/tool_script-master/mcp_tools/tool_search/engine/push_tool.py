import csv
import json
import requests
from typing import Dict, List


class PushTool:
    def __init__(self):
        self.input_path = "data/cloud_share/mcp_tools/tool_search/engine/tool_schema.tsv"
        self.push_url = "http://ssai-data-center-lids-testtwo.ssai-apis-staging.chj.cloud/ssai-data-center/v1/agent-tool-admin/content"
        self.operator = "liwenjing3"
        self.msg_id = "test_add_tool"

    @staticmethod
    def build_tool_index_text(schema: Dict) -> str:
        tool_name_zh = schema.get("tool_name_zh", "")
        tool_intro = schema.get("tool_intro", "")
        tool_desc = schema.get("tool_desc", "")
        return f"{tool_name_zh}；{tool_intro}；{tool_desc}"

    def read_schemas(self) -> List[Dict]:
        schemas = []
        with open(self.input_path, "r", encoding="utf-8") as f:
            reader = csv.DictReader(f, delimiter="\t")
            for row in reader:
                schema_str = row.get("schema")
                if not schema_str:
                    continue

                schema = json.loads(schema_str)
                schemas.append(schema)

        return schemas

    def build_push_content(self, schemas: List[Dict]) -> List[Dict]:
        content = []

        for schema in schemas:
            schema["tool_index_text"] = self.build_tool_index_text(schema)

            item = {
                "tool_id": schema.get("tool_id"),
                "tool_type": schema.get("tool_type"),
                "agent_card_id": schema.get("agent_card_id"),
                "agent_card_name": schema.get("agent_card_name"),
                "agent_card_desc": schema.get("agent_card_desc"),
                "tool_name": schema.get("tool_name"),
                "tool_name_zh": schema.get("tool_name_zh"),
                "tool_intro": schema.get("tool_intro"),
                "tool_desc": schema.get("tool_desc"),
                "tool_params": json.dumps(
                    schema.get("tool_params", {}),
                    ensure_ascii=False,
                    indent=2,
                ),
                "tool_response": json.dumps(
                    schema.get("tool_response", {}),
                    ensure_ascii=False,
                    indent=2,
                ),
                "tool_index_text": schema.get("tool_index_text"),
                "operator": self.operator,
            }
            content.append(item)

        return content

    def push(self, content: List[Dict]):
        payload = {
            "msg_id": self.msg_id,
            "content": content,
        }

        resp = requests.post(
            self.push_url,
            json=payload,
            timeout=10,
        )

        if resp.status_code != 200:
            print("HTTP Status:", resp.status_code)
            print("Response Text:", resp.text)
            resp.raise_for_status()

        return resp.json()

    def chunk_list(self, data: List[Dict], chunk_size: int = 10):
        for i in range(0, len(data), chunk_size):
            yield data[i:i + chunk_size]

    def process(self):
        schemas = self.read_schemas()
        if not schemas:
            print("No schema found.")
            return

        content = self.build_push_content(schemas)

        for idx, batch in enumerate(self.chunk_list(content, 10), start=1):
            print(f"Pushing batch {idx}, size={len(batch)}")
            try:
                result = self.push(batch)
                print(f"Batch {idx} success: {result}")
            except Exception as e:
                print(f"Batch {idx} failed: {e}")
                break


if __name__ == "__main__":
    obj = PushTool()
    obj.process()

# python -m mcp_tools.tool_search.engine.push_tool
