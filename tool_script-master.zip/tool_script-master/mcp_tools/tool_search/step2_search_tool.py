import json
import pandas as pd
from tqdm import tqdm
from typing import List
from loguru import logger
from utils.file_utils import read_jsonl_file
from utils.search_utils.memory_qdrant import MemoryQdrant
from utils.nlp_utils.embedding_client_new import EmbeddingClient
from mcp_tools.tool_search.meta import *


class SearchTool:

    def __init__(self):
        self.candidate_query_path = f"{DATA_DIR}/query_v2.tsv"
        self.tool_index_path = f"{DATA_DIR}/step1_build_tool_index.jsonl"
        self.tool_query_path = f"{DATA_DIR}/step1_build_query_index.jsonl"
        self.output_path = f"{DATA_DIR}/step2_search_tool.tsv"
        self.tool_stat_path = f"{DATA_DIR}/step2_search_tool_stat.tsv"

        self.embedding_client = EmbeddingClient(vector_dim=QUERY_DIM)

        self.tool2index_text = {}

    def read_queries(self, query_path: str):
        logger.info(f"读取候选查询：{query_path}")
        df = pd.read_csv(query_path, sep="\t")

        tool_type_list = df["工具类型"].tolist()
        query_list = df["query"].tolist()
        real_query_list = df["tool"].tolist()

        logger.info(f"共读取 {len(query_list)} 条 query")
        return tool_type_list, query_list, real_query_list

    def process(self):
        # 构建索引
        text_index = self.build_index(self.tool_index_path)
        query_index = self.build_query_index(self.tool_query_path)

        # 发起搜索
        tool_type_list, query_text_list, real_query_list = self.read_queries(self.candidate_query_path)
        retriever_result_list = self.do_retriever(
            text_index, tool_type_list, query_text_list, prefix="tool", real_query_list=real_query_list, query_index=query_index)

        df = pd.DataFrame(retriever_result_list)
        df.to_csv(self.output_path, sep="\t", index=False, header=True)
        logger.info(f"Search result saved to {self.output_path}")

        stat_df = (
            df
            .groupby("tool", as_index=False)
            .agg(
                tool_type=("tool_type", "first"),
                tool_count=("tool", "count"),
                **{
                    "correct@3": ("tool_acc@3", "sum"),
                    "acc@3": ("tool_acc@3", "mean"),
                    "correct@5": ("tool_acc@5", "sum"),
                    "acc@5": ("tool_acc@5", "mean"),
                    "correct@21": ("tool_acc@21", "sum"),
                    "acc@21": ("tool_acc@21", "mean"),
                }
            )
        )

        stat_df["acc@3"] = stat_df["acc@3"].round(6)
        stat_df["acc@5"] = stat_df["acc@5"].round(6)
        stat_df["acc@21"] = stat_df["acc@21"].round(6)

        stat_df.to_csv(self.tool_stat_path, sep="\t", index=False)
        logger.info(f"Search result stat saved to {self.tool_stat_path}")

    def multi_recall_v2(self, text_index: MemoryQdrant, query_embedding):

        recall_results = []

        # 1. 车端召回 2 个
        recall_results.extend(
            text_index.search(
                query_embedding,
                top_k=RECALL_NUM_CAR,
                filter={
                    "must": [
                        {"key": "tool_type", "match": {"value": "车端"}}
                    ]
                }
            )
        )

        # 2. 云端召回 3 个
        recall_results.extend(
            text_index.search(
                query_embedding,
                top_k=RECALL_NUM_ClOUD,
                filter={
                    "must": [
                        {"key": "tool_type", "match": {"value": "云端"}}
                    ]
                }
            )
        )

        uniq = {}
        for item in recall_results:
            tool_name = item["payload"]["tool_name"]
            if tool_name not in uniq or item["score"] > uniq[tool_name]["score"]:
                uniq[tool_name] = item

        return sorted(uniq.values(), key=lambda x: x["score"], reverse=True)[:RECALL_NUM]

    def multi_recall_v3(self, text_index: MemoryQdrant, query_embedding):
        recall_results = []

        # 1. 车端召回 2 个
        recall_results.extend(
            text_index.search(
                query_embedding,
                top_k=RECALL_NUM_CAR,
                filter={
                    "must": [
                        {"key": "tool_type", "match": {"value": "车端"}}
                    ]
                }
            )
        )

        # 2. 云端召回 2 个
        recall_results.extend(
            text_index.search(
                query_embedding,
                top_k=RECALL_NUM_ClOUD,
                filter={
                    "must": [
                        {"key": "tool_type", "match": {"value": "云端"}}
                    ]
                }
            )
        )

        # 3. 默认召回 general_search
        recall_results.extend(
            text_index.search(
                query_embedding,
                top_k=RECALL_NUM_DEFAULT,
                filter={
                    "must": [
                        {"key": "tool_name", "match": {"value": DEFAULT_TOOL_NAME}}
                    ]
                }
            )
        )

        uniq = {}
        for item in recall_results:
            tool_name = item["payload"]["tool_name"]
            if tool_name not in uniq or item["score"] > uniq[tool_name]["score"]:
                uniq[tool_name] = item

        return sorted(uniq.values(), key=lambda x: x["score"], reverse=True)[:RECALL_NUM]

    def multi_recall_v4(self, tool_index: MemoryQdrant, query_index: MemoryQdrant, query_embedding):
        recall_results = []

        def mark(items, source):
            for it in items:
                it["payload"]["recall_source"] = source
            return items

        # query-query 车端
        recall_results.extend(
            mark(
                query_index.search(
                    query_embedding,
                    top_k=5,
                    filter={"must": [{"key": "tool_type", "match": {"value": "车端"}}]}
                ),
                "query_query_car"
            )
        )

        # query-query 云端
        recall_results.extend(
            mark(
                query_index.search(
                    query_embedding,
                    top_k=5,
                    filter={"must": [{"key": "tool_type", "match": {"value": "云端"}}]}
                ),
                "query_query_cloud"
            )
        )

        # tool-desc 车端
        recall_results.extend(
            mark(
                tool_index.search(
                    query_embedding,
                    top_k=5,
                    filter={"must": [{"key": "tool_type", "match": {"value": "车端"}}]}
                ),
                "query_desc_car"
            )
        )

        # tool-desc 云端
        recall_results.extend(
            mark(
                tool_index.search(
                    query_embedding,
                    top_k=5,
                    filter={"must": [{"key": "tool_type", "match": {"value": "云端"}}]}
                ),
                "query_desc_cloud"
            )
        )

        # 兜底 general_search
        recall_results.extend(
            mark(
                tool_index.search(
                    query_embedding,
                    top_k=1,
                    filter={"must": [{"key": "tool_name", "match": {"value": DEFAULT_TOOL_NAME}}]}
                ),
                "default"
            )
        )

        return recall_results

    def build_index(self, tool_index_path):
        logger.info("构建 tool 索引")
        text_index = MemoryQdrant()
        index_list = read_jsonl_file(tool_index_path)

        for point in index_list:
            text_index.add_points([point])

            tool_name = point.get("payload", {}).get("tool_name")
            if tool_name:
                self.tool2index_text[tool_name] = point.get("index_text", "")

        return text_index

    def build_query_index(self, query_index_path):
        logger.info("构建 query 索引")
        query_index = MemoryQdrant()
        index_list = read_jsonl_file(query_index_path)

        for point in index_list:
            query_index.add_points([point])

        return query_index

    def do_retriever(self, text_index: MemoryQdrant, tool_type_list: List[str], query_text_list: List[str], prefix: str = "", real_query_list: List[str] = None, query_index: MemoryQdrant = None):
        logger.info("发起搜索")
        retriever_result_list = []

        for batch_start in tqdm(range(0, len(query_text_list), BATCH_SIZE), desc="Embedding & Search"):
            batch_queries = query_text_list[batch_start: batch_start + BATCH_SIZE]

            embeddings = []
            for query in batch_queries:
                vec = self.embedding_client.embed(query)
                embeddings.append(vec if vec else None)

            for idx, query in enumerate(batch_queries):
                query_embedding = embeddings[idx]

                if not query_embedding or len(query_embedding) != QUERY_DIM:
                    logger.warning(
                        f"Query embedding dim mismatch, expect={QUERY_DIM}, got={len(query_embedding) if query_embedding else 0}, skip item")
                    continue

                if RECALL_STRATEGY == "v1":
                    item_list = text_index.search(query_embedding, top_k=RECALL_NUM)
                elif RECALL_STRATEGY == "v2":
                    item_list = self.multi_recall_v2(text_index, query_embedding)
                elif RECALL_STRATEGY == "v3":
                    item_list = self.multi_recall_v3(text_index, query_embedding)
                elif RECALL_STRATEGY == "v4":
                    if query_index is None:
                        raise ValueError("v4 召回需要 query_index")
                    item_list = self.multi_recall_v4(text_index, query_index, query_embedding)
                else:
                    raise ValueError(f"Unknown RECALL_STRATEGY: {RECALL_STRATEGY}")

                real_tool = real_query_list[batch_start + idx] if real_query_list is not None else None

                retriever_result_item = {
                    "tool_type": tool_type_list[batch_start + idx] if tool_type_list else "",
                    "tool": real_tool if real_tool else "",
                    "query": query,
                    f"{prefix}_retriever_result": self.format_retriever_result(
                        item_list,
                        real_tool
                    )
                }

                # tool_pos / tool_score
                top_tools = [item["payload"]["tool_name"] for item in item_list]

                if real_tool and real_tool in top_tools:
                    tool_pos = top_tools.index(real_tool) + 1
                    tool_score = round(item_list[tool_pos - 1]["score"], 6)
                else:
                    tool_pos = -1
                    tool_score = 0

                retriever_result_item[f"{prefix}_pos"] = tool_pos
                retriever_result_item[f"{prefix}_score"] = tool_score

                # acc@n
                if real_tool:
                    retriever_result_item[f"{prefix}_acc@3"] = 1 if 1 <= tool_pos <= 3 else 0
                    retriever_result_item[f"{prefix}_acc@5"] = 1 if 1 <= tool_pos <= 5 else 0
                    retriever_result_item[f"{prefix}_acc@16"] = 1 if 1 <= tool_pos <= 16 else 0
                    retriever_result_item[f"{prefix}_acc@21"] = 1 if 1 <= tool_pos <= 21 else 0

                retriever_result_list.append(retriever_result_item)

        return retriever_result_list

    def format_retriever_result(self, item_list, real_tool: str = None):
        result = []

        for item in item_list:
            payload = item["payload"]
            tool_name = payload["tool_name"]
            score = round(item["score"], 6)

            result.append({
                "score": score,
                "tool_name": tool_name,
                "index_text": self.tool2index_text.get(tool_name, ""),
                "recall_source": payload.get("recall_source", ""),
                "acc": 1 if real_tool and tool_name == real_tool else 0
            })

        return json.dumps(result, ensure_ascii=False, indent=4)


if __name__ == "__main__":
    obj = SearchTool()
    obj.process()

# python -m mcp_tools.tool_search.step2_search_tool
