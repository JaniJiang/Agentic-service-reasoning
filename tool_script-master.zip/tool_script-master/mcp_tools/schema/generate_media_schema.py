import json
import hashlib
import pandas as pd


class GenerateToolSchema:

    def __init__(self):
        self.input_path = "data/cloud_share/mcp_tools/schema/input_media.tsv"
        self.output_path = "data/cloud_share/mcp_tools/schema/output_media_schema.tsv"

    @staticmethod
    def md5(text: str) -> str:
        return hashlib.md5(text.encode("utf-8")).hexdigest()

    def build_tool_schema(self, tool: dict) -> dict:
        tool_name = tool.get("name", "")
        input_schema = tool.get("inputSchema", {}).get("json", {})

        return {
            "tool_id": self.md5(tool_name),
            "tool_type": "车端",
            "agent_card_id": self.md5("媒体播放"),
            "agent_card_name": "媒体播放",
            "agent_card_desc": "播放新闻、音乐、视频等资源",
            "tool_name": tool_name,
            "tool_name_zh": "播放视频" if tool_name == "video_play" else "播放音乐",
            "tool_intro": "播放影视资源" if tool_name == "video_play" else "播放音乐资源",
            "tool_desc": tool.get("description", ""),
            "tool_params": {
                "type": "object",
                "properties": input_schema.get("properties", {}),
                "required": input_schema.get("required", [])
            },
            "tool_response": {
                "type": "object",
                "properties": {}
            }
        }

    def process(self):
        df = pd.read_csv(self.input_path, sep="\t")

        output_rows = []
        for _, row in df.iterrows():
            tool = json.loads(row["tool_schema_json"])
            output_rows.append({
                "tool_name": tool.get("name", ""),
                "tool_schema": json.dumps(
                    self.build_tool_schema(tool),
                    ensure_ascii=False, indent=4
                )
            })

        out_df = pd.DataFrame(output_rows)
        out_df.to_csv(self.output_path, sep="\t", index=False)


if __name__ == "__main__":
    GenerateToolSchema().process()

# python -m mcp_tools.schema.generate_media_schema
