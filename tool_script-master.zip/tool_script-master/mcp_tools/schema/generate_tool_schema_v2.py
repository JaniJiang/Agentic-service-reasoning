import json
import hashlib
import pandas as pd


class GenerateToolSchema:

    def __init__(self):
        self.input_path = "data/cloud_share/mcp_tools/schema/input_tool.tsv"
        self.output_path = "data/cloud_share/mcp_tools/schema/output_tool_schema.tsv"

    @staticmethod
    def md5(text: str) -> str:
        return hashlib.md5(text.encode("utf-8")).hexdigest()

    def process(self):
        input_df = pd.read_csv(self.input_path, sep="\t").fillna("")
        output_list = []

        for _, row in input_df.iterrows():
            if row["优先级"] != "P0":
                continue

            params_dict, required_params_list = self.parse_input_params(row["工具输入参数"])

            tool_schema_dict = {
                "tool_id": self.md5(row["工具名称"]),
                "tool_type": "云端",
                "agent_card_id": self.md5(row["AgentCard"]),
                "agent_card_name": row["AgentCard"],
                "agent_card_desc": row["AgentCard描述"],
                "tool_name": row["工具名称"],
                "tool_name_zh": row["工具中文名"],
                "tool_intro": row["工具简介"],
                "tool_desc": row["工具详细描述"],
                "tool_params": {
                    "type": "object",
                    "properties": params_dict,
                    "required": required_params_list,
                },
                "tool_response": {
                    "type": "object",
                    "properties": {},
                }
            }

            output_list.append(json.dumps(tool_schema_dict, ensure_ascii=False, indent=4))

        pd.DataFrame(output_list).to_csv(
            self.output_path, sep="\t", index=False, header=False
        )

    def parse_input_params(self, params_str: str):
        params_dict = {}
        required_params_list = []

        if not params_str:
            return params_dict, required_params_list

        for param_str in params_str.split("\n"):
            try:
                param_name, param_conf = param_str.split(":")
            except:
                print(params_str)
            try:
                param_type, param_desc, param_required, param_demo = param_conf.split("|")
            except:
                print("===")
                print(params_str)

            if param_demo != "无" and not (param_demo.startswith("[") and param_demo.endswith("]")):
                description = f"{param_desc}，比如{param_demo}等"
            else:
                description = param_desc

            params_dict[param_name] = {
                "type": param_type,
                "description": description,
            }

            if param_demo.startswith("[") and param_demo.endswith("]"):
                params_dict[param_name]["enum"] = param_demo.strip("[]").split("、")

            if param_required == "必选":
                required_params_list.append(param_name)

        return params_dict, required_params_list


if __name__ == "__main__":
    GenerateToolSchema().process()

# python -m mcp_tools.schema.generate_tool_schema_v2
