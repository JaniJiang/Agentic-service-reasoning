import json
import hashlib
import pandas as pd


class GenerateCarSchema:

    def __init__(self):
        self.input_path = "data/cloud_share/mcp_tools/schema/input_car.tsv"
        self.output_path = "data/cloud_share/mcp_tools/schema/output_car_schema.tsv"

    @staticmethod
    def md5(text: str) -> str:
        if not text:
            return ""
        return hashlib.md5(text.encode("utf-8")).hexdigest()

    def parse_tool_params(self, params_str: str):
        if not params_str:
            return {
                "type": "object",
                "properties": {}
            }

        try:
            schema_obj = json.loads(params_str)
        except Exception:
            return {
                "type": "object",
                "properties": {}
            }

        json_schema = schema_obj.get("json", {})
        properties = json_schema.get("properties", {})
        required = json_schema.get("required", [])

        parsed_properties = {}
        for name, info in properties.items():
            prop = {
                "type": info.get("type", ""),
                "description": info.get("description", "")
            }
            if "enum" in info:
                prop["enum"] = info["enum"]
            parsed_properties[name] = prop

        tool_params = {
            "type": "object",
            "properties": parsed_properties
        }
        if required:
            tool_params["required"] = required

        return tool_params

    def process(self):
        df = pd.read_csv(self.input_path, sep="\t", dtype=str).fillna("")
        output_list = []

        for _, row in df.iterrows():
            tool_schema = {
                "tool_id": self.md5(row["工具名称"]),
                "tool_type": "车端",
                "agent_card_id": self.md5(row["AgentCard"]),
                "agent_card_name": row["AgentCard"],
                "agent_card_desc": row["AgentCard描述"],
                "tool_name": row["工具名称"],
                "tool_name_zh": row["工具中文名"],
                "tool_intro": row["工具简介"],
                "tool_desc": row["工具详细描述"],
                "tool_params": self.parse_tool_params(row["工具输入参数"]),
                "tool_response": {
                    "type": "object",
                    "properties": {}
                }
            }

            output_list.append(
                json.dumps(tool_schema, ensure_ascii=False, indent=4)
            )

        pd.DataFrame(output_list).to_csv(
            self.output_path,
            sep="\t",
            index=False,
            header=False
        )


if __name__ == "__main__":
    GenerateCarSchema().process()

# python -m mcp_tools.schema.generate_car_schema
