import pandas as pd


class SplitCarQuery:

    def __init__(self):
        self.input_path = "data/cloud_share/mcp_tools/schema/output_car_tool_query_v2.tsv"
        self.output_path1 = "data/cloud_share/mcp_tools/schema/output_car_tool_query_1.tsv"
        self.output_path2 = "data/cloud_share/mcp_tools/schema/output_car_tool_query_2.tsv"

    def process(self):
        df = pd.read_csv(self.input_path, sep="\t")

        rows_out1 = []
        rows_out2 = []

        # 按 tool 分组
        for tool, group in df.groupby("tool_name", sort=False):
            group = group.reset_index(drop=True)
            n = len(group)
            n_out2 = (n + 1) // 2
            n_out1 = n - n_out2

            rows_out1.append(group.iloc[:n_out1])
            rows_out2.append(group.iloc[n_out1:])

        df_out1 = pd.concat(rows_out1, ignore_index=True) if rows_out1 else df.iloc[0:0]
        df_out2 = pd.concat(rows_out2, ignore_index=True) if rows_out2 else df.iloc[0:0]

        df_out1.to_csv(self.output_path1, sep="\t", index=False)
        df_out2.to_csv(self.output_path2, sep="\t", index=False)


if __name__ == "__main__":
    SplitCarQuery().process()

# python -m mcp_tools.schema.split_car_query
