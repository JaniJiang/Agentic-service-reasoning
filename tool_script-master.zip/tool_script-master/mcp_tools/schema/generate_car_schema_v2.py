import json
import hashlib
import pandas as pd


class GenerateCarSchema:

    def __init__(self):
        self.input_path = "data/cloud_share/mcp_tools/schema/input_car_v2.tsv"

        self.output_query_path = "data/cloud_share/mcp_tools/schema/output_car_tool_query_v2.tsv"
        self.output_schema_path = "data/cloud_share/mcp_tools/schema/output_car_tool_schema_v2.tsv"

    @staticmethod
    def md5(text: str) -> str:
        return hashlib.md5(text.encode("utf-8")).hexdigest()

    def process(self):
        df = pd.read_csv(self.input_path, sep="\t")

        query_records = []
        schema_map = {}

        for _, row in df.iterrows():
            query = str(row.get("query", "")).strip()

            if not query or query.lower() == "none":
                continue

            tool_raw = row.get("工具")
            if pd.isna(tool_raw):
                continue

            try:
                tool_json = json.loads(tool_raw)
            except Exception:
                continue

            function_info = tool_json.get("function", {})
            tool_name = function_info.get("name")
            if not tool_name:
                continue

            query_records.append({
                "tool_name": tool_name,
                "query": query
            })

            if tool_name in schema_map:
                continue

            tool_id = self.md5(tool_name)

            schema = {
                "tool_id": tool_id,
                "tool_type": "车端",
                "agent_card_id": "",
                "agent_card_name": "",
                "agent_card_desc": "",
                "tool_name": tool_name,
                "tool_name_zh": "",
                "tool_intro": "",
                "tool_desc": function_info.get("description", ""),
                "tool_params": function_info.get("parameters", {}),
                "tool_response": {
                    "type": "object",
                    "properties": {}
                }
            }

            schema_map[tool_name] = json.dumps(schema, ensure_ascii=False, indent=4)

        query_df = pd.DataFrame(query_records)
        query_df.to_csv(self.output_query_path, sep="\t", index=False)

        schema_df = pd.DataFrame([
            {"tool_name": k, "schema": v}
            for k, v in schema_map.items()
        ])
        schema_df.to_csv(self.output_schema_path, sep="\t", index=False)

        print(f"{len(query_df)} 条 query 输出到 {self.output_query_path}")
        print(f"{len(schema_df)} 个 schema 输出到 {self.output_schema_path}")


if __name__ == "__main__":
    GenerateCarSchema().process()

# python -m mcp_tools.schema.generate_car_schema_v2
