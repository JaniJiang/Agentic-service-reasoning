# 汽车实体检索

## 介绍
https://li.feishu.cn/wiki/KhB1w6FAlizlZlkXj2FcW2eZnog
- 增加服务专家中的实体检索预期能解决 
    - 预期能解决33.5%的大模型链路问题（=39%*50%+28%*50%）
    - 大模型链路完成率提升至90%(+5%) （=33.5%*15.63%）

---

## 1. 实体生产的流程
### 1.1 数据收集&维护
![alt text](image.png)
![alt text](image-1.png)

### 1.2 实体识别与抽取
基于大模型进行实体抽取、分类，从多来源构造实体数据
search/qa_bot/entity_recall/generate_new_data/generate_new_entity.py

### 1.3 实体校验
对大模型生成的实体、分类进行半监督的校验
search/qa_bot/entity_recall/auto_check

### 1.4 doc数据生产
基于QA和三元组数据生成doc，逻辑见
search/qa_bot/entity_recall/generate_new_data/generate_doc.py

### 1.5 帮助手册
从帮助手册抽取数据，暂未使用，由于帮助手册受OTA变动较大
search/qa_bot/entity_recall/generate_new_data/get_data_from_help.py

---
## 2. 检索Demo

search/qa_bot/entity_recall/search
