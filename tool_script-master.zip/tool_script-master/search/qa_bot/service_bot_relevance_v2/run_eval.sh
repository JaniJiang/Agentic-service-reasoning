#!/usr/bin/env bash
set -e

python -m search.qa_bot.service_bot_relevance_v2.eval.step1_eval
python -m search.qa_bot.service_bot_relevance_v2.eval.step2_label

# sh search/qa_bot/service_bot_relevance_v2/run_eval.sh 