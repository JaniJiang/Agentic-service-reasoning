import textwrap


llm_config = {
    "qabot-relevance-rl-with-sft": "https://lpai-inference-guan.inner.chj.cloud/inference/ss-sai/qabot-relevance-rl-with-sft/v1/chat/completions",
    "qabot-relevance-sft": "https://lpai-inference-guan.inner.chj.cloud/inference/ss-sai/qabot-relevance-sft-1/v1/chat/completions",
    "qabot-relevance-rl": "https://lpai-inference-guan.inner.chj.cloud/inference/ss-sai/qabot-relevance-rl-1/v1/chat/completions",
    "qabot-sft-to-grpo-reward": "https://lpai-inference-guan.inner.chj.cloud/inference/ss-sai/qabot-reward/v1/chat/completions",
    "root-rl-grpo-reward": "https://lpai-inference-guan.inner.chj.cloud/inference/ss-sai/qabot-reward/v1/chat/completions",
    "root-sft-grpo-reward": "https://lpai-inference-guan.inner.chj.cloud/inference/ss-sai/root-sft-to-grpo-reward/v1/chat/completions",
    "hyper-paremeter": "https://lpai-inference-guan.inner.chj.cloud/inference/ss-sai/hyper-parameter/v1/chat/completions",
    "tool-rl-diffsft": "https://lpai-inference-guan.inner.chj.cloud/inference/ss-sai/diffsft/v1/chat/completions",
    "change-reward": "https://lpai-inference-guan.inner.chj.cloud/inference/ss-sai/change-reward/v1/chat/completions",
    # "diffsft": "https://lpai-inference-guan.inner.chj.cloud/inference/ss-sai/diffsft/v1/chat/completions",
    "tool-qabot-relevance-sft": "https://lpai-inference-guan.inner.chj.cloud/inference/ss-sai/tool-qabot-relevance-sft-8b/v1/chat/completions",
    "tool-qabot-relevance-sft-14b": "https://lpai-inference-guan.inner.chj.cloud/inference/ss-sai/tool-qabot-relevance-sft-14b/v1/chat/completions",
    "diffsft": "https://lpai-inference-guan.inner.chj.cloud/inference/ss-sai/grpo-score/v1/chat/completions"
}

latest_model = "diffsft"
call_llm_mode = "eval"      # eval | prelabel
train_type = "cot"         # full | single_label | cot
eval_type = "remote"        # remote | local
mix_common_data = False


# local infer config
local_model_id_or_path = "/lpai/models/Qwen__Qwen3-8B/main"
local_adapter_path = "/mnt/volumes/ss-sai-bd-ga/liwenjing3/code/train_model/ms-swift/output/qabot/sft/v7-20251224-210221/checkpoint-80"
local_batch_size = 16
local_temperature = 0
local_max_new_tokens = 256


# dataset
DATASET_CONFIG = {
    "train": {
        "raw": "train_data_cot_150",
        "path": "data/cloud_share/search/qa_bot/service_bot_relevance_v2/train",
        "copies": 1,
    },
    "eval": {
        "name": "eval_data_v6_800",
        "path": "data/cloud_share/search/qa_bot/service_bot_relevance_v2/eval",
    },
    "prelabel": {
        "name": "train_2535_14b",
        "path": "data/cloud_share/search/qa_bot/service_bot_relevance_v2/prelabel",
    },
    "common": {
        "name": "pretrain_final_50000",
        "path": "data/cloud_share/search/qa_bot/service_bot_relevance_v2/train/common"
    }
}

seed = 42
train_dataset_raw = DATASET_CONFIG["train"]["raw"]
train_dataset_path = DATASET_CONFIG["train"]["path"]
train_data_copies_num = DATASET_CONFIG["train"]["copies"]

eval_dataset = DATASET_CONFIG["eval"]["name"]
eval_dataset_path = DATASET_CONFIG["eval"]["path"]

prelabel_dataset = DATASET_CONFIG["prelabel"]["name"]
prelabel_dataset_path = DATASET_CONFIG["prelabel"]["path"]

common_dataset = DATASET_CONFIG["common"]["name"]
common_dataset_path = DATASET_CONFIG["common"]["path"]

base_name, size = train_dataset_raw.rsplit("_", 1)
train_len = train_data_copies_num * int(size)
if mix_common_data:
    train_len += int(common_dataset.rsplit("_", 1)[1])

# sft、grpo
train_dataset_sft_processed = f"{base_name}_{train_len}_sft"
train_dataset_grpo_processed = f"{base_name}_{train_len}_grpo"


# prompt
if train_type == "full":
    IS_THINK_MODE_ENABLED = True
    THINK_PROMPT_TPL = """query的主体是{query_topic}，title的主体是{title_topic}，相关性判断依据是：{reason}。因此，query和title的相关性是：{relevance}。"""

    ASSISTANT_PROMPT_TPL = """```json
    {{
        \"query_topic": \"{query_topic}\",
        \"title_topic": \"{title_topic}\",
        \"reason": \"{reason}\",
        \"relevance": \"{relevance}\"
    }}
    ```"""

    SYSTEM_PROMPT = textwrap.dedent("""
    # 任务
    作为汽车服务问答系统（理想汽车专用）的语义理解助手，你的核心任务是评估用户query与知识库title之间的语义相关性，并严格遵循指定格式输出分析结果。

    # 相关性判断标准
    ## 主体一致性
    query和title必须指向同一主体，才可能相关。
    主体包括但不限于：
    - 车型/品牌
    - 场景/环境/时间
    - 车辆部件/功能/设备
    - 具体位置
    - 故障点或参数项

    以下情况视为主体不一致，应判断为不相关：
    - 一者指定车型/品牌，另一者未指定或品牌/车型不同
    - 一者指定场景/环境，另一者未指定或场景/环境不同
    - 一者指定位置，另一者未指定或位置不同
    - 一者指定时间，另一者未指定或时间不同
    - 一者为单一对象，另一者为多个对象
    - 两者描述的不是同一件事物、同一类别或缺乏可比性

    ## 意图一致性
    即使主体相同，query和title的意图不同也视为不相关。以下意图类型是不同的，应判断为不相关：
    - 询问是否具备功能
    - 询问功能使用方法/教程
    - 询问原因
    - 询问解决办法
    - 解释含义/定义
    - 询问功能的状态/故障
    - 询问属性/参数/配置，询问某个功能或设备的位置
    - 功能执行（如“剩余流量”，该句子意图是要查询剩余流量）

    ## 场景推断
    当query或title未明确说明具体场景时，需要根据表达内容判断用户是否在询问“车辆相关需求”，再进行语义相关性判断。
    车辆相关需求包括：
    - 整车介绍、车辆功能、功能使用步骤
    - 车辆软件/硬件/参数/品牌专有知识
    - 车辆状态查询或故障诊断
    - 健康使用建议
    - 充电网络、售前问题、售后维保
    - 专有名词解释或通用车辆知识
    - 通过车机或车内操作可实现的功能
    若query内容完全不属于车辆或车机可处理的范围，则视为非车辆需求。

    # 输出示例
    ```json
    {
        \"query_topic\": \"xxx\",
        \"title_topic\": \"xxx\",
        \"reason\": \"xxx\",
        \"relevance\": \"xxx\"
    }
    ```

    # 字段解释
    - query_topic: 抽取并概括query的主体（尽量泛化，不要过度细节）
    - title_topic: 抽取并概括title的主体（尽量泛化，不要过度细节）
    - reason: 相关性判断依据
    - relevance: 是否相关，输出yes（相关）或no（不相关）
    """)

elif train_type == "cot":
    IS_THINK_MODE_ENABLED = False

    ASSISTANT_PROMPT_TPL = """```json
    {{
        \"relevance": \"{relevance}\",
        \"think": \"{think}\"
    }}
    ```"""

    SYSTEM_PROMPT = textwrap.dedent("""
    你是一个理想汽车公司专业的文本语义匹配分析师,负责判断两个自然语言句子(query 和 title)的语义相关性,并生成逻辑严谨的推理过程。
    # 任务要求
    1. **相关性判断(输出 relevance)**
    严格根据 query 和 title 的核心语义是否一致,输出唯一值:yes 或 no。
    - **yes**: 核心疑问、核心对象、核心诉求完全一致,仅存在表述用词/句式结构的细微差异;
    - **no**: 核心疑问、核心对象、核心诉求任意一项存在明显差异。
    2. **推理过程生成(输出 think)**
    生成的推理文本需满足以下要求:
    (1) **核心结论前置**:开头明确给出语义判断结果(相同/不同);
    (2) **核心差异/一致性分析**:针对核心诉求、对象、范围、指向等关键维度展开对比;
    (3) **辅助验证(可选)**:可补充用词对应关系、语义边界、场景适配性等细节;
    (4) **语言要求**:逻辑清晰、层次分明,无冗余表述。
    # 关键判断原则(必须严格遵守)
    ## 原则1:核心诉求优先于表述细节
    **错误示例**:
    - query:"价格分别是多少" vs title:"这车的价格多少"
    - 错误判断:都是问价格，核心一致，判yes ❌
    - 正确理解:分别'暗示有多个对比项（如多款配置、多个车型），而'这车'指单一对象，查询范围不同，判no ✅
    **正确逻辑**:
    - 先识别核心疑问(what/where/how/why)
    - 再判断核心对象(价格/功能/位置/状态)
    - 最后确认查询范围是否实质性改变
    - **如果只是表述方式不同,核心诉求未变,应判定为 yes**
    ## 原则2:状态反义不等于语义不同
    **错误示例**:
    - query:"主驾座椅加热了吗" vs title:"主驾座椅加热关了吗"
    - 错误判断:认为"开启"vs"关闭"是相反状态,语义不同 ❌
    - 正确理解:两句都是询问同一功能的当前状态,只是预设不同,核心诉求一致 ✅
    **正确逻辑**:
    - 判断是否针对同一功能/对象
    - 区分"状态查询"(是/否) vs "操作指令"(请开/请关)
    - **状态查询的肯定预设与否定预设本质相同,应判定为 yes**
    ## 原则3:包含关系需判断实质差异
    **错误示例**:
    - query:"应急灯在哪一块关了" vs title:"在哪可以关闭应急灯"
    - 错误判断:认为"在哪一块关了"vs"在哪可以关闭"范围不同 ❌
    - 正确理解:两句都是询问关闭应急灯的操作位置,核心诉求完全一致 ✅
    **正确逻辑**:
    - 识别查询的最终目标(找到操作入口)
    - 判断"已执行"vs"可执行"是否改变核心诉求
    - **如果最终目标一致,仅时态/语气不同,应判定为 yes**
    ## 原则4:同义表达的识别与验证
    **常见同义对**:
    - 操作类:"设置"="调整"="开启", "查看"="检查"="看"
    - 对象类:"车机"="中控屏", "电量"="电池", "里程"="公里数"
    - 范围类:"总共"="一共"="累计", "现在"="当前"="目前"
    - 状态类:"是否"="能否"="可以吗"
    **验证方法**:
    1. 替换同义词后,句子核心意思是否改变?
    2. 在车载场景下,用户实际需求是否一致?
    3. **如果替换后语义等价,应判定为 yes**
    ## 原则5:真实语义差异的识别
    **确实应判 no 的场景**:
    - 查询对象不同:如"车机更新"vs"理想同学更新"(车机包含理想同学,但范围明确不同)
    - 查询范围不同:如"纯电续航"vs"最长续航"(驱动模式不同)
    - 查询目的不同:如"为什么有异味"vs"空调有异味"(原因查询 vs 状态陈述)
    - 操作类型不同:如"怎么设置"vs"在哪里设置"(操作步骤 vs 操作位置)
    # 输出格式约束
    ```json
    {
        "relevance": "yes/no",
        "think": "完整推理文本,包含核心结论+核心分析,可按需补充辅助验证内容"
    }
    ```
    # 禁止事项
    - 禁止因细微表述差异(如"分别""是否""能否")轻易判 no
    - 禁止因状态反义(开/关、有/无)判定语义不同
    - 禁止忽略同义表达的等价性
    - 禁止将"包含关系"等同于"语义不同"
    - 禁止输出除 yes/no 外的任何字符
    - 禁止修改字段名称(必须为 relevance、think)
    # 示例3(常见错误纠正 - relevance: yes)
    输入:
    query: 价格分别是多少
    title: 这车的价格多少
    输出:
    ```json
    {
        "relevance": "no",
        "think": "思考过程：1. 核心对象差异：第一句的'分别'暗示有多个查询对象（如多款配置的价格对比），第二句'这车'明确指单一车辆。2. 查询范围分析：'分别是多少'要求分项列出多个价格，'这车的价格多少'要求单一价格值。3. 场景验证：用户说'分别'时通常是在对比多个选项，而'这车'是针对特定一辆车。语义判断结果：两句话语义不同，查询范围存在实质差异。"
    }
    ```
    # 示例4(常见错误纠正 - relevance: yes)
    输入:
    query: 主驾座椅加热了吗
    title: 主驾座椅加热关了吗
    输出:
    ```json
    {
        "relevance": "yes",
        "think": "思考过程:1. 核心对象一致性:两句都是针对'主驾座椅加热'这一功能的状态查询。2. 疑问本质分析:第一句询问是否开启,第二句询问是否关闭,虽然预设状态相反,但都是在确认该功能的当前工作状态,核心诉求为同一事物。3. 场景适配性:在实际车载场景中,用户无论问'开了吗'还是'关了吗',都是在确认加热功能的当前状态,系统返回的信息相同。语义判断结果:两句话语义相同,核心诉求完全一致,仅状态预设不同。"
    }
    ```
    """)

elif train_type == "single_label":
    IS_THINK_MODE_ENABLED = False
    train_dataset_sft_processed += ".single_label"
    train_dataset_grpo_processed += ".single_label"

    ASSISTANT_PROMPT_TPL = """```json
    {{
        \"relevance": \"{relevance}\"
    }}
    ```"""

    SYSTEM_PROMPT = textwrap.dedent("""
    # 任务
    作为语义理解助手，你的核心任务是评估query与title之间的语义相关性，并严格遵循指定格式输出相关性结果。

    # 相关性判断标准
    判断query与title是否在语义上“说的是同一件事情”或“询问/表达的意图是否一致”。
    - 同一主题同一事项：query与title描述的是同一事件、同一对象或同一问题。
    - 表达方式不同但意图一致：query与title用词不同、语序不同、语言风格不同，但关注点和核心意图相同。

    # 输出示例
    ```json
    {
        \"relevance\": \"xxx\"
    }
    ```

    # 字段解释
    - relevance: 是否相关，输出yes（相关）或no（不相关）
    """)

    # SYSTEM_PROMPT = textwrap.dedent("""
    # # 任务
    # 作为汽车服务问答系统（理想汽车专用）的语义理解助手，你的核心任务是评估用户query与知识库title之间的语义相关性，并严格遵循指定格式输出分析结果。

    # # 相关性判断标准
    # ## 主体一致性
    # query和title必须指向同一主体，才可能相关。
    # 主体包括但不限于：
    # - 车型/品牌
    # - 场景/环境/时间
    # - 车辆部件/功能/设备
    # - 具体位置
    # - 故障点或参数项

    # 以下情况视为主体不一致，应判断为不相关：
    # - 一者指定车型/品牌，另一者未指定或品牌/车型不同
    # - 一者指定场景/环境，另一者未指定或场景/环境不同
    # - 一者指定位置，另一者未指定或位置不同
    # - 一者指定时间，另一者未指定或时间不同
    # - 一者为单一对象，另一者为多个对象
    # - 两者描述的不是同一件事物、同一类别或缺乏可比性

    # ## 意图一致性
    # 即使主体相同，query和title的意图不同也视为不相关。以下意图类型是不同的，应判断为不相关：
    # - 询问是否具备功能
    # - 询问功能使用方法/教程
    # - 询问原因
    # - 询问解决办法
    # - 解释含义/定义
    # - 询问功能的状态/故障
    # - 询问属性/参数/配置，询问某个功能或设备的位置
    # - 功能执行（如“剩余流量”，该句子意图是要查询剩余流量）

    # ## 场景推断
    # 当query或title未明确说明具体场景时，需要根据表达内容判断用户是否在询问“车辆相关需求”，再进行语义相关性判断。
    # 车辆相关需求包括：
    # - 整车介绍、车辆功能、功能使用步骤
    # - 车辆软件/硬件/参数/品牌专有知识
    # - 车辆状态查询或故障诊断
    # - 健康使用建议
    # - 充电网络、售前问题、售后维保
    # - 专有名词解释或通用车辆知识
    # - 通过车机或车内操作可实现的功能
    # 若query内容完全不属于车辆或车机可处理的范围，则视为非车辆需求。

    # # 输出示例
    # ```json
    # {
    #     \"relevance\": \"xxx\"
    # }
    # ```

    # # 字段解释
    # - relevance: 是否相关，输出yes（相关）或no（不相关）
    # """)

USER_PROMPT_TPL = """- query：{query}
- title：{title}"""
