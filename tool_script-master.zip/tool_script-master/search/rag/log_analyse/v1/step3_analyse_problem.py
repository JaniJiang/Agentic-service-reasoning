import json
import pandas as pd
from collections import Counter


class AnalyseProblem:

    def __init__(self):
        date = "2025-03-25"  # "2025-03-18"
        self.input_path = f"data/cloud/search/rag/log_analyse/v1/{date}/step2_calculate_search_metrics.tsv"
        self.output_path = f"data/cloud/search/rag/log_analyse/v1/{date}/step3_analyse_problem"
        self.distribution_field_list = ["is_recall", "label_msg"]

    def process(self):
        input_df = pd.read_csv(self.input_path, delimiter="\t")
        input_df["P准确问题"] = ""
        input_df["P不确定问题"] = ""
        api_query_dict = {}
        del_mask = pd.Series([False] * len(input_df))
        label_msg_list = []
        recall_all_count, recall_real_count, unrecall_count = 0, 0, 0
        p_reason_type_list = []
        p2_reason_type_list = []
        acc_reason_type_list = []
        p_all_count = 0
        acc_all_count = 0
        for idx, row in input_df.iterrows():
            api_query = row["api_query"]
            if api_query not in api_query_dict:
                api_query_dict[api_query] = True
                del_mask[idx] = False
            else:  # 兼容step2的脏数据
                del_mask[idx] = True
                continue
            # 分析召回
            pv = row["pv"]
            recall_all_count += pv
            if row["is_recall"] == 0:
                unrecall_count += pv
                label_msg_list.extend([row["label_msg"]] * pv)
                continue
            else:
                recall_real_count += pv
            # 分析准确
            bad_reason_type_list = []
            uncertain_reason_type_list = []
            label_llm = json.loads(row["label_llm"])
            for item in label_llm:
                if item.get("label", "") == "不满足":
                    reason_type = item.get("reason_type", "")
                    if reason_type != "":
                        bad_reason_type_list.append(reason_type)
                elif item.get("label", "") == "不确定":
                    reason_type = item.get("reason_type", "")
                    if reason_type != "":
                        uncertain_reason_type_list.append(reason_type)
            p_all_count += pv
            if row["label_p"] == 0:
                bad_reason_type_uniq = ";".join(sorted(list(set(bad_reason_type_list))))
                if bad_reason_type_uniq != "":
                    for _ in range(pv):
                        p_reason_type_list.append(bad_reason_type_uniq)
                uncertain_reason_type_uniq = ";".join(sorted(list(set(uncertain_reason_type_list))))
                if uncertain_reason_type_uniq != "":
                    for _ in range(pv):
                        p2_reason_type_list.append(uncertain_reason_type_uniq)
            else:
                bad_reason_type_uniq = ""
                uncertain_reason_type_uniq = ""
            acc_all_count += row["label_num"] * pv
            for _ in range(pv):
                acc_reason_type_list.extend(bad_reason_type_list)
            input_df.loc[idx, "P准确问题"] = bad_reason_type_uniq
            input_df.loc[idx, "P不确定问题"] = uncertain_reason_type_uniq
        # 保存处理结果数据
        input_df = input_df.loc[~del_mask]  # 删除step2的脏数据
        input_df.to_csv(self.output_path + ".tsv", sep="\t", index=False)
        # 计算&保存指标
        with open(self.output_path + ".metrics.tsv", "w") as f_write:
            # 召回指标
            self.write_metrics(f_write, "召回指标", "recall", recall_real_count, recall_all_count)
            self.write_metrics(f_write, "召回指标", "unrecall", unrecall_count, recall_all_count)
            # 召回问题占比
            label_msg_counts = Counter(label_msg_list)
            for key, value in label_msg_counts.items():
                self.write_metrics(f_write, "召回问题占比", key, value, recall_all_count)
            # 准确问题占比
            p_reason_type_counts = Counter(p_reason_type_list)
            for key, value in p_reason_type_counts.items():
                self.write_metrics(f_write, "准确问题占比", key, value, recall_all_count)
            # 不确定问题占比
            p2_reason_type_counts = Counter(p2_reason_type_list)
            for key, value in p2_reason_type_counts.items():
                self.write_metrics(f_write, "不确定问题占比", key, value, recall_all_count)
            # P指标
            for key, value in p_reason_type_counts.items():
                self.write_metrics(f_write, "P指标", key, value, p_all_count)
            # ACC指标
            acc_reason_type_counts = Counter(acc_reason_type_list)
            for key, value in acc_reason_type_counts.items():
                self.write_metrics(f_write, "ACC指标", key, value, acc_all_count)
            print("recall_all_count:", recall_all_count)
            print("p_all_count:", p_all_count)
            print("acc_all_count:", acc_all_count)

    def write_metrics(self, f_write, metrics_type, metrics_key, metrics_value_a, metrics_value_b):
        metrics_rate = "{:.2%}".format(round(metrics_value_a / metrics_value_b, 4))
        metrics_one = [metrics_type, metrics_key, metrics_rate, metrics_value_a, metrics_value_b]
        f_write.write("\t".join([str(x) for x in metrics_one]) + "\n")


if __name__ == "__main__":
    obj = AnalyseProblem()
    obj.process()

# python -m search.rag.log_analyse.v1.step3_analyse_problem
